/* @flow */

import { vi, describe, it, expect, beforeEach, afterEach } from "vitest";
import {
  isWebView,
  isIosWebview,
  isAndroidWebview,
  isFacebookWebView,
  isOperaMini,
  isFirefoxIOS,
  isEdgeIOS,
  isQQBrowser,
  isElectron,
  supportsPopups,
  isTablet,
  isIos,
  isSafari,
  isAndroid,
  isChrome,
  isFirefox,
} from "@krakenjs/belter/src";

import {
  getFundingSourceColors,
  supportsVenmoPopups,
  isSupportedNativeVenmoBrowser,
} from "./util";

// Mock all the browser detection functions from belter
vi.mock("@krakenjs/belter/src", () => ({
  isWebView: vi.fn(),
  isIosWebview: vi.fn(),
  isAndroidWebview: vi.fn(),
  isFacebookWebView: vi.fn(),
  isOperaMini: vi.fn(),
  isFirefoxIOS: vi.fn(),
  isEdgeIOS: vi.fn(),
  isQQBrowser: vi.fn(),
  isElectron: vi.fn(),
  supportsPopups: vi.fn(),
  isTablet: vi.fn(),
  isIos: vi.fn(),
  isSafari: vi.fn(),
  isAndroid: vi.fn(),
  isChrome: vi.fn(),
  isFirefox: vi.fn(),
}));

describe("funding/util", () => {
  const defaultUserAgent =
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1";

  beforeEach(() => {
    // Reset all mocks before each test
    vi.clearAllMocks();

    // Reset window.popupBridge
    delete window.popupBridge;

    // Set default mock return values
    vi.mocked(isWebView).mockReturnValue(false);
    vi.mocked(isIosWebview).mockReturnValue(false);
    vi.mocked(isAndroidWebview).mockReturnValue(false);
    vi.mocked(isFacebookWebView).mockReturnValue(false);
    vi.mocked(isOperaMini).mockReturnValue(false);
    vi.mocked(isFirefoxIOS).mockReturnValue(false);
    vi.mocked(isEdgeIOS).mockReturnValue(false);
    vi.mocked(isQQBrowser).mockReturnValue(false);
    vi.mocked(isElectron).mockReturnValue(false);
    vi.mocked(supportsPopups).mockReturnValue(true);
    vi.mocked(isTablet).mockReturnValue(false);
    vi.mocked(isIos).mockReturnValue(false);
    vi.mocked(isSafari).mockReturnValue(false);
    vi.mocked(isAndroid).mockReturnValue(false);
    vi.mocked(isChrome).mockReturnValue(false);
    vi.mocked(isFirefox).mockReturnValue(false);
  });

  afterEach(() => {
    vi.resetAllMocks();
  });

  describe("getFundingSourceColors", () => {
    const mockFundingConfig = {
      colors: ["gold", "blue", "silver"],
      colorsRebrand: ["blue", "black", "white"],
      logoColors: { default: "blue", white: "blue" },
      logoColorsRebrand: { blue: "black", black: "white", white: "black" },
      secondaryColors: { default: "silver", black: "black" },
      secondaryColorsRebrand: { default: "white", black: "black" },
      textColors: { gold: "black", blue: "white" },
      textColorsRebrand: { default: "black", blue: "black", black: "white" },
    };

    it("should return legacy color fields when shouldApplyRebrandedStyles is false", () => {
      const result = getFundingSourceColors({
        // $FlowFixMe
        fundingConfig: mockFundingConfig,
        shouldApplyRebrandedStyles: false,
      });

      expect(result.colors).toBe(mockFundingConfig.colors);
      expect(result.logoColors).toBe(mockFundingConfig.logoColors);
      expect(result.secondaryColors).toBe(mockFundingConfig.secondaryColors);
      expect(result.textColors).toBe(mockFundingConfig.textColors);
    });

    it("should return rebrand color fields when shouldApplyRebrandedStyles is true", () => {
      const result = getFundingSourceColors({
        // $FlowFixMe
        fundingConfig: mockFundingConfig,
        shouldApplyRebrandedStyles: true,
      });

      expect(result.colors).toBe(mockFundingConfig.colorsRebrand);
      expect(result.logoColors).toBe(mockFundingConfig.logoColorsRebrand);
      expect(result.secondaryColors).toBe(
        mockFundingConfig.secondaryColorsRebrand
      );
      expect(result.textColors).toBe(mockFundingConfig.textColorsRebrand);
    });

    it("should fall back to legacy colors array when shouldApplyRebrandedStyles is true but colorsRebrand is not defined", () => {
      const configWithoutColorsRebrand = {
        ...mockFundingConfig,
        colorsRebrand: undefined,
      };

      const result = getFundingSourceColors({
        // $FlowFixMe
        fundingConfig: configWithoutColorsRebrand,
        shouldApplyRebrandedStyles: true,
      });

      expect(result.colors).toBe(configWithoutColorsRebrand.colors);
    });

    it("should still return rebrand logo/secondary/text colors even when colorsRebrand is not defined", () => {
      const configWithoutColorsRebrand = {
        ...mockFundingConfig,
        colorsRebrand: undefined,
      };

      const result = getFundingSourceColors({
        // $FlowFixMe
        fundingConfig: configWithoutColorsRebrand,
        shouldApplyRebrandedStyles: true,
      });

      expect(result.logoColors).toBe(
        configWithoutColorsRebrand.logoColorsRebrand
      );
      expect(result.secondaryColors).toBe(
        configWithoutColorsRebrand.secondaryColorsRebrand
      );
      expect(result.textColors).toBe(
        configWithoutColorsRebrand.textColorsRebrand
      );
    });
  });

  describe("supportsVenmoPopups", () => {
    describe("when in supported webview", () => {
      beforeEach(() => {
        vi.mocked(isWebView).mockReturnValue(true);
      });

      it("should return true when popupBridge is available", () => {
        window.popupBridge = {};

        expect(supportsVenmoPopups({}, true, defaultUserAgent)).toBe(true);
      });

      it("should return false when popupBridge is not available", () => {
        expect(supportsVenmoPopups({}, false, defaultUserAgent)).toBe(false);
      });
    });

    describe("when not in supported webview", () => {
      it("should return true when experiment flag is enabled and user agent supports popups", () => {
        vi.mocked(supportsPopups).mockReturnValue(true);
        const experiment = { venmoEnableWebOnNonNativeBrowser: true };

        expect(supportsVenmoPopups(experiment, true, defaultUserAgent)).toBe(
          true
        );
      });

      it("should return false when experiment flag is enabled but user agent doesn't support popups due to isOperaMini", () => {
        vi.mocked(isOperaMini).mockReturnValue(true);
        const experiment = { venmoEnableWebOnNonNativeBrowser: true };

        expect(supportsVenmoPopups(experiment, false, defaultUserAgent)).toBe(
          false
        );
      });

      it("should return false when experiment flag is enabled but user agent doesn't support popups due to isFirefoxIOS", () => {
        vi.mocked(isFirefoxIOS).mockReturnValue(true);
        const experiment = { venmoEnableWebOnNonNativeBrowser: true };

        expect(supportsVenmoPopups(experiment, false, defaultUserAgent)).toBe(
          false
        );
      });

      it("should return false when experiment flag is enabled but user agent doesn't support popups due to isEdgeIOS", () => {
        vi.mocked(isEdgeIOS).mockReturnValue(true);
        const experiment = { venmoEnableWebOnNonNativeBrowser: true };

        expect(supportsVenmoPopups(experiment, false, defaultUserAgent)).toBe(
          false
        );
      });

      it("should return false when experiment flag is enabled but user agent doesn't support popups due to isQQBrowser", () => {
        vi.mocked(isQQBrowser).mockReturnValue(true);
        const experiment = { venmoEnableWebOnNonNativeBrowser: true };

        expect(supportsVenmoPopups(experiment, false, defaultUserAgent)).toBe(
          false
        );
      });

      it("should return false when experiment flag is enabled but user agent doesn't support popups due to isElectron", () => {
        vi.mocked(isElectron).mockReturnValue(true);
        const experiment = { venmoEnableWebOnNonNativeBrowser: true };

        expect(supportsVenmoPopups(experiment, false, defaultUserAgent)).toBe(
          false
        );
      });

      it("should fall back to supportsPopups when experiment flag is not enabled", () => {
        vi.mocked(supportsPopups).mockReturnValue(true);
        const experiment = {};

        expect(supportsVenmoPopups(experiment, true, defaultUserAgent)).toBe(
          true
        );
      });

      it("should fall back to supportsPopups when experiment flag is false", () => {
        vi.mocked(supportsPopups).mockReturnValue(false);
        const experiment = { venmoEnableWebOnNonNativeBrowser: false };

        expect(supportsVenmoPopups(experiment, false, defaultUserAgent)).toBe(
          false
        );
      });

      it("should handle undefined experiment", () => {
        vi.mocked(supportsPopups).mockReturnValue(true);

        expect(supportsVenmoPopups(undefined, true, defaultUserAgent)).toBe(
          true
        );
      });
    });
  });

  describe("isSupportedNativeVenmoBrowser", () => {
    describe("when in supported webview", () => {
      beforeEach(() => {
        vi.mocked(isWebView).mockReturnValue(true);
      });

      it("should return true when popupBridge is available", () => {
        window.popupBridge = {};

        expect(isSupportedNativeVenmoBrowser({}, defaultUserAgent)).toBe(true);
      });

      it("should return false when popupBridge is not available", () => {
        expect(isSupportedNativeVenmoBrowser({}, defaultUserAgent)).toBe(false);
      });
    });

    describe("when not in supported webview", () => {
      it("should return false when on tablet", () => {
        vi.mocked(isTablet).mockReturnValue(true);

        expect(isSupportedNativeVenmoBrowser({}, defaultUserAgent)).toBe(false);
      });

      it("should return true for iOS Safari by default", () => {
        vi.mocked(isIos).mockReturnValue(true);
        vi.mocked(isSafari).mockReturnValue(true);

        expect(isSupportedNativeVenmoBrowser({}, defaultUserAgent)).toBe(true);
      });

      it("should return true for Android Chrome by default", () => {
        vi.mocked(isAndroid).mockReturnValue(true);
        vi.mocked(isChrome).mockReturnValue(true);

        expect(isSupportedNativeVenmoBrowser({}, defaultUserAgent)).toBe(true);
      });

      it("should return false for iOS Chrome without experiment flag", () => {
        vi.mocked(isIos).mockReturnValue(true);
        vi.mocked(isChrome).mockReturnValue(true);

        expect(isSupportedNativeVenmoBrowser({}, defaultUserAgent)).toBe(false);
      });

      it("should return true for iOS Chrome with experiment flag", () => {
        vi.mocked(isIos).mockReturnValue(true);
        vi.mocked(isChrome).mockReturnValue(true);
        const experiment = { venmoEnableWebOnNonNativeBrowser: true };

        expect(
          isSupportedNativeVenmoBrowser(experiment, defaultUserAgent)
        ).toBe(true);
      });

      it("should return false for Android Firefox without experiment flag", () => {
        vi.mocked(isAndroid).mockReturnValue(true);
        vi.mocked(isFirefox).mockReturnValue(true);

        expect(isSupportedNativeVenmoBrowser({}, defaultUserAgent)).toBe(false);
      });

      it("should return true for Android Firefox with experiment flag", () => {
        vi.mocked(isAndroid).mockReturnValue(true);
        vi.mocked(isFirefox).mockReturnValue(true);
        const experiment = { venmoEnableWebOnNonNativeBrowser: true };

        expect(
          isSupportedNativeVenmoBrowser(experiment, defaultUserAgent)
        ).toBe(true);
      });

      it("should return false for unsupported browser combinations", () => {
        vi.mocked(isIos).mockReturnValue(true);
        vi.mocked(isFirefox).mockReturnValue(true); // iOS Firefox (not Chrome)

        expect(isSupportedNativeVenmoBrowser({}, defaultUserAgent)).toBe(false);
      });

      it("should return false for desktop browsers", () => {
        // No mobile flags set, simulating desktop

        expect(isSupportedNativeVenmoBrowser({}, defaultUserAgent)).toBe(false);
      });

      it("should handle undefined experiment", () => {
        vi.mocked(isIos).mockReturnValue(true);
        vi.mocked(isSafari).mockReturnValue(true);

        expect(isSupportedNativeVenmoBrowser(undefined, defaultUserAgent)).toBe(
          true
        );
      });

      it("should prioritize tablet check over browser checks", () => {
        vi.mocked(isTablet).mockReturnValue(true);
        vi.mocked(isIos).mockReturnValue(true);
        vi.mocked(isSafari).mockReturnValue(true);

        expect(isSupportedNativeVenmoBrowser({}, defaultUserAgent)).toBe(false);
      });
    });
  });
});
