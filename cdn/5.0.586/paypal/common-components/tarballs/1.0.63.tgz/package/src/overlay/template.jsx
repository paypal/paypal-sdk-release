/* @flow */
/** @jsx node */
/* eslint max-lines: off, react/jsx-max-depth: off */

import {
  isIos,
  isIpadOs,
  isFirefox,
  animate,
  noop,
  destroyElement,
  uniqueID,
  supportsPopups,
  type EventEmitterType,
  toCSS,
} from "@krakenjs/belter/src";
import { EVENT, CONTEXT } from "@krakenjs/zoid/src";
import { node, type ElementNode } from "@krakenjs/jsx-pragmatic/src";
import {
  LOGO_COLOR,
  PayPalRebrandLogo,
  VenmoLogo,
} from "@paypal/sdk-logos/src";
import { type ZalgoPromise } from "@krakenjs/zalgo-promise/src";

import {
  getContainerStyle,
  getSandboxStyle,
  getVenmoContainerStyle,
  getVenmoSandboxStyle,
  CLASS,
} from "./style";

function setupReturnFocus(
  el: HTMLElement,
  event: EventEmitterType,
  getFocusTarget: () => ?HTMLElement
) {
  const ownerWindow = el.ownerDocument && el.ownerDocument.defaultView;

  if (!ownerWindow) {
    return;
  }

  const focusOverlay = () => {
    const focusTarget = getFocusTarget();
    if (focusTarget) {
      try {
        focusTarget.focus();
      } catch (err) {
        // focus() can throw in rare cross-frame situations; ignore.
      }
    }
  };

  event.on(EVENT.DISPLAY, () => {
    focusOverlay();
    ownerWindow.addEventListener("focus", focusOverlay);
  });

  const removeFocusListener = () => {
    ownerWindow.removeEventListener("focus", focusOverlay);
  };

  event.on(EVENT.CLOSE, removeFocusListener);
  event.on(EVENT.DESTROY, removeFocusListener);
}

const FOCUSABLE_SELECTOR =
  'a[href], button, input, select, textarea, iframe:not([tabindex="-1"]), [tabindex]:not([tabindex="-1"])';

const FOCUS_TRAP_SENTINEL_ATTR = "data-focus-trap-sentinel";

function getFocusableElements(root: HTMLElement): $ReadOnlyArray<HTMLElement> {
  return Array.prototype.slice
    .call(root.querySelectorAll(FOCUSABLE_SELECTOR))
    .filter((candidate) => candidate.getClientRects().length > 0)
    .filter((candidate) => !candidate.hasAttribute(FOCUS_TRAP_SENTINEL_ATTR));
}

function setupFocusTrap(getRoot: () => ?HTMLElement, event: EventEmitterType) {
  let handleKeyDown: ?(KeyboardEvent) => void;
  let ownerDocument: ?Document;
  let sentinelCleanups: Array<() => void> = [];

  // The checkout iframe is cross-origin, so its document
  // is never accessible, and even same-origin, keyboard events never
  // cross frame/document boundaries - a `keydown` listener on the overlay's
  // own document can't see a Tab press that happens once focus is inside it.
  // What *does* fire in our own document is a native `focus` event once the
  // browser's own focus traversal moves focus out of the exhausted iframe -
  // that's a UA-level mechanism independent of script access into the frame.
  // These sentinels sit just before/after the overlay's real content so
  // whichever direction focus naturally escapes, it lands on something we
  // control and can redirect back into the trap.
  const createSentinel = (doc: Document, position: "start" | "end") => {
    const sentinel = doc.createElement("span");
    sentinel.setAttribute("tabindex", "0");
    sentinel.setAttribute(FOCUS_TRAP_SENTINEL_ATTR, position);
    sentinel.style.position = "fixed";
    sentinel.style.width = "1px";
    sentinel.style.height = "1px";
    sentinel.style.opacity = "0";
    sentinel.style.pointerEvents = "none";
    return sentinel;
  };

  event.on(EVENT.DISPLAY, () => {
    const root = getRoot();
    ownerDocument = root && root.ownerDocument;

    if (!root || !ownerDocument) {
      return;
    }

    const doc = ownerDocument;

    handleKeyDown = (e: KeyboardEvent) => {
      if (e.key !== "Tab") {
        return;
      }

      const focusable = getFocusableElements(root);

      if (!focusable.length) {
        return;
      }

      const first = focusable[0];
      const activeIndex = focusable.indexOf(doc.activeElement);

      if (e.shiftKey) {
        if (activeIndex <= 0) {
          e.preventDefault();
          focusable[focusable.length - 1].focus();
        }
      } else if (activeIndex === -1 || activeIndex === focusable.length - 1) {
        e.preventDefault();
        first.focus();
      }
    };

    doc.addEventListener("keydown", handleKeyDown, true);

    const startSentinel = createSentinel(doc, "start");
    const endSentinel = createSentinel(doc, "end");

    const handleStartSentinelFocus = () => {
      const liveRoot = getRoot();
      const focusable = liveRoot ? getFocusableElements(liveRoot) : [];
      const last = focusable[focusable.length - 1];

      if (last) {
        last.focus();
      }
    };

    const handleEndSentinelFocus = () => {
      const liveRoot = getRoot();
      const focusable = liveRoot ? getFocusableElements(liveRoot) : [];
      const first = focusable[0];

      if (first) {
        first.focus();
      }
    };

    startSentinel.addEventListener("focus", handleStartSentinelFocus);
    endSentinel.addEventListener("focus", handleEndSentinelFocus);

    root.insertBefore(startSentinel, root.firstChild);
    root.appendChild(endSentinel);

    sentinelCleanups.push(() => {
      startSentinel.removeEventListener("focus", handleStartSentinelFocus);
      endSentinel.removeEventListener("focus", handleEndSentinelFocus);

      if (startSentinel.parentNode) {
        startSentinel.parentNode.removeChild(startSentinel);
      }

      if (endSentinel.parentNode) {
        endSentinel.parentNode.removeChild(endSentinel);
      }
    });
  });

  const removeKeyDownListener = () => {
    if (ownerDocument && handleKeyDown) {
      ownerDocument.removeEventListener("keydown", handleKeyDown, true);
    }

    sentinelCleanups.forEach((cleanup) => cleanup());
    sentinelCleanups = [];
  };

  event.on(EVENT.CLOSE, removeKeyDownListener);
  event.on(EVENT.DESTROY, removeKeyDownListener);
}

export type OverlayProps = {|
  context: $Values<typeof CONTEXT>,
  close: () => ZalgoPromise<void>,
  focus: () => ZalgoPromise<void>,
  event: EventEmitterType,
  frame: ?HTMLElement,
  prerenderFrame: ?HTMLElement,
  content?: void | {|
    windowMessage?: string,
    continueMessage?: string,
    cancelMessage?: string,
    interrogativeMessage?: string,
  |},
  autoResize?: boolean,
  hideCloseButton?: boolean,
  nonce: string,
  fullScreen?: boolean,
  isUnbrandedFlow?: boolean, // eslint-disable-line react/no-unused-prop-types
|};

export function Overlay({
  context,
  close,
  focus,
  event,
  frame,
  prerenderFrame,
  content = {},
  autoResize,
  hideCloseButton,
  nonce,
  fullScreen = false,
  isUnbrandedFlow = false,
}: OverlayProps): ElementNode {
  const uid = `paypal-overlay-${uniqueID()}`;
  const overlayIframeName = `__paypal_checkout_sandbox_${uid}__`;

  let closeButtonEl: ?HTMLElement;
  let sandboxIframeEl: ?HTMLElement;
  let overlayRootEl: ?HTMLElement;

  function closeCheckout(e) {
    e.preventDefault();
    e.stopPropagation();
    close();
  }

  function displayFocusWarning() {
    const overlayIframe: ?HTMLIFrameElement =
      //  $FlowFixMe
      document.getElementsByName(overlayIframeName)?.[0];
    const iframeDocument = overlayIframe?.contentWindow.document;
    const warningElement = iframeDocument?.getElementsByClassName(
      "paypal-checkout-focus-warning-hidden"
    )?.[0];

    if (!warningElement) {
      return;
    }
    warningElement.innerText = `Still can't see it? Select "Window" in your toolbar to find "Log in to your PayPal account"`;
    warningElement.classList.remove("paypal-checkout-focus-warning-hidden");
  }

  function focusCheckout(e) {
    e.preventDefault();
    e.stopPropagation();

    if (!supportsPopups()) {
      return;
    }

    // Give the overlay itself a definite focused element before handing
    // focus off to the popup window - without this, the browser has no
    // valid "last focused descendant" to restore focus to within this
    // iframe when the window later regains focus (e.g. switching back from
    // the popup), regardless of what was clicked to get here.
    const focusTarget = closeButtonEl || sandboxIframeEl;
    if (focusTarget) {
      focusTarget.focus();
    }

    if (isIos() || isIpadOs()) {
      // Note: alerts block the event loop until they are closed.
      // eslint-disable-next-line no-alert
      window.alert("Please switch tabs to reactivate the PayPal window");
    } else if (isFirefox()) {
      displayFocusWarning();
    }
    focus();
  }

  const setupAnimations = (name) => {
    return (el) => {
      const showContainer = () => animate(el, `show-${name}`, noop);
      const hideContainer = () => animate(el, `hide-${name}`, noop);
      event.on(EVENT.DISPLAY, showContainer);
      event.on(EVENT.CLOSE, hideContainer);
    };
  };

  const setupAutoResize = (el) => {
    event.on(EVENT.RESIZE, ({ width: newWidth, height: newHeight }) => {
      if (typeof newWidth === "number") {
        el.style.width = toCSS(newWidth);
      }

      if (typeof newHeight === "number") {
        el.style.height = toCSS(newHeight);
      }
    });
  };

  const outletOnRender = (el) => {
    setupAnimations("component")(el);
    if (autoResize) {
      setupAutoResize(el);
    }
  };

  let outlet;

  if (frame && prerenderFrame) {
    frame.classList.add(CLASS.COMPONENT_FRAME);
    prerenderFrame.classList.add(CLASS.PRERENDER_FRAME);

    prerenderFrame.classList.add(CLASS.VISIBLE);
    frame.classList.add(CLASS.INVISIBLE);

    event.on(EVENT.RENDERED, () => {
      prerenderFrame.classList.remove(CLASS.VISIBLE);
      prerenderFrame.classList.add(CLASS.INVISIBLE);

      frame.classList.remove(CLASS.INVISIBLE);
      frame.classList.add(CLASS.VISIBLE);

      setTimeout(() => {
        destroyElement(prerenderFrame);
      }, 1);
    });

    outlet = (
      <div class={CLASS.OUTLET} onRender={outletOnRender}>
        <node el={frame} />
        <node el={prerenderFrame} />
      </div>
    );
  }

  const containerOnRender = (el) => {
    setupAnimations("container")(el);
    setupReturnFocus(el, event, () => closeButtonEl || sandboxIframeEl);
  };

  setupFocusTrap(() => overlayRootEl, event);

  return (
    <div id={uid} onRender={containerOnRender} class="paypal-checkout-sandbox">
      <style nonce={nonce}>{getSandboxStyle({ uid })}</style>
      <iframe
        title="PayPal Checkout Overlay"
        name={overlayIframeName}
        scrolling="no"
        tabindex="-1"
        onRender={(el) => {
          sandboxIframeEl = el;
        }}
        class={`paypal-checkout-sandbox-iframe${fullScreen ? "-full" : ""}`}
      >
        <html>
          <body>
            <div
              dir="auto"
              id={uid}
              onClick={focusCheckout}
              onRender={(el) => {
                overlayRootEl = el;
              }}
              class={`paypal-overlay-context-${context} paypal-checkout-overlay`}
            >
              {!hideCloseButton && (
                <a
                  href="#"
                  class="paypal-checkout-close"
                  onClick={closeCheckout}
                  onRender={(el) => {
                    closeButtonEl = el;
                  }}
                  aria-label="close"
                  role="button"
                />
              )}
              {!fullScreen && (
                <div class="paypal-checkout-modal">
                  {/* Cannot have any PayPal branding for unbranded flows */}
                  {isUnbrandedFlow ? null : (
                    <div class="paypal-checkout-logo" dir="ltr">
                      <PayPalRebrandLogo logoColor={LOGO_COLOR.WHITE} />
                    </div>
                  )}
                  {content.windowMessage && (
                    <div class="paypal-checkout-message">
                      {content.windowMessage}
                    </div>
                  )}
                  <div class="paypal-checkout-focus-warning paypal-checkout-focus-warning-hidden" />
                  {content.continueMessage && (
                    <div class="paypal-checkout-continue">
                      {/* This handler should be guarded with e.stopPropagation. 
                          This will stop the event from bubbling up to the overlay click handler
                          and causing unexpected behavior. */}
                      <a onClick={focusCheckout} href="#">
                        {content.continueMessage}
                      </a>
                    </div>
                  )}
                  <div class="paypal-checkout-loader">
                    <div class="paypal-spinner" />
                  </div>
                </div>
              )}
              <div
                class={
                  fullScreen
                    ? "paypal-checkout-iframe-container-full"
                    : "paypal-checkout-iframe-container"
                }
              >
                {outlet}
              </div>

              <style nonce={nonce}>{getContainerStyle({ uid })}</style>
            </div>
          </body>
        </html>
      </iframe>
    </div>
  );
}

export function VenmoOverlay({
  context,
  close,
  focus,
  event,
  frame,
  prerenderFrame,
  content = {},
  autoResize,
  hideCloseButton,
  nonce,
  fullScreen = false,
}: OverlayProps): ElementNode {
  const uid = `venmo-overlay-${uniqueID()}`;
  const overlayIframeName = `__venmo_checkout_sandbox_${uid}__`;

  let closeButtonEl: ?HTMLElement;
  let sandboxIframeEl: ?HTMLElement;
  let overlayRootEl: ?HTMLElement;

  function closeCheckout(e) {
    e.preventDefault();
    e.stopPropagation();
    close();
  }

  function displayFocusWarningVenmo() {
    const overlayIframe: ?HTMLIFrameElement =
      // $FlowFixMe
      document.getElementsByName(overlayIframeName)?.[0];
    const iframeDocument = overlayIframe?.contentWindow.document;
    const warningElement = iframeDocument?.getElementsByClassName(
      "venmo-checkout-focus-warning-hidden"
    )?.[0];

    if (!warningElement) {
      return;
    }

    warningElement.innerText = `Still can't see it? Select "Window" in your toolbar to find "Log in to your Venmo account"`;
    warningElement.classList.remove("venmo-checkout-focus-warning-hidden");
  }

  function focusCheckout(e) {
    e.preventDefault();
    e.stopPropagation();

    if (!supportsPopups()) {
      return;
    }

    // Give the overlay itself a definite focused element before handing
    // focus off to the popup window - without this, the browser has no
    // valid "last focused descendant" to restore focus to within this
    // iframe when the window later regains focus (e.g. switching back from
    // the popup), regardless of what was clicked to get here.
    const focusTarget = closeButtonEl || sandboxIframeEl;
    if (focusTarget) {
      focusTarget.focus();
    }

    if (isIos()) {
      // Note: alerts block the event loop until they are closed.
      // eslint-disable-next-line no-alert
      window.alert("Please switch tabs to reactivate the Venmo window");
    } else if (isFirefox()) {
      displayFocusWarningVenmo();
    }
    focus();
  }

  const setupAnimations = (name) => {
    return (el) => {
      const showContainer = () => animate(el, `show-${name}`, noop);
      const hideContainer = () => animate(el, `hide-${name}`, noop);
      event.on(EVENT.DISPLAY, showContainer);
      event.on(EVENT.CLOSE, hideContainer);
    };
  };

  const setupAutoResize = (el) => {
    event.on(EVENT.RESIZE, ({ width: newWidth, height: newHeight }) => {
      if (typeof newWidth === "number") {
        el.style.width = toCSS(newWidth);
      }

      if (typeof newHeight === "number") {
        el.style.height = toCSS(newHeight);
      }
    });
  };

  const outletOnRender = (el) => {
    setupAnimations("component")(el);
    if (autoResize) {
      setupAutoResize(el);
    }
  };

  let outlet;

  if (frame && prerenderFrame) {
    frame.classList.add(CLASS.COMPONENT_FRAME);
    prerenderFrame.classList.add(CLASS.PRERENDER_FRAME);

    prerenderFrame.classList.add(CLASS.VISIBLE);
    frame.classList.add(CLASS.INVISIBLE);

    event.on(EVENT.RENDERED, () => {
      prerenderFrame.classList.remove(CLASS.VISIBLE);
      prerenderFrame.classList.add(CLASS.INVISIBLE);

      frame.classList.remove(CLASS.INVISIBLE);
      frame.classList.add(CLASS.VISIBLE);

      setTimeout(() => {
        destroyElement(prerenderFrame);
      }, 1);
    });

    outlet = (
      <div class={CLASS.OUTLET} onRender={outletOnRender}>
        <node el={frame} />
        <node el={prerenderFrame} />
      </div>
    );
  }

  const containerOnRender = (el) => {
    setupAnimations("container")(el);
    setupReturnFocus(el, event, () => closeButtonEl || sandboxIframeEl);
  };

  setupFocusTrap(() => overlayRootEl, event);

  return (
    <div id={uid} onRender={containerOnRender} class="venmo-checkout-sandbox">
      <style nonce={nonce}>{getVenmoSandboxStyle({ uid })}</style>
      <iframe
        title="Venmo Checkout Overlay"
        name={overlayIframeName}
        scrolling="no"
        tabindex="-1"
        onRender={(el) => {
          sandboxIframeEl = el;
        }}
        class={`venmo-checkout-sandbox-iframe${fullScreen ? "-full" : ""}`}
      >
        <html>
          <body>
            <div
              id={uid}
              onClick={focusCheckout}
              onRender={(el) => {
                overlayRootEl = el;
              }}
              class={`venmo-overlay-context-${context} venmo-checkout-overlay`}
            >
              {!fullScreen && (
                <div class="venmo-checkout-modal">
                  <div class="venmo-checkout-logo">
                    <VenmoLogo logoColor={LOGO_COLOR.WHITE} />
                  </div>
                  {content.interrogativeMessage && (
                    <div class="venmo-interrogative-message">
                      {content.interrogativeMessage}
                    </div>
                  )}
                  <div class="venmo-checkout-focus-warning venmo-checkout-focus-warning-hidden" />
                  {content.windowMessage && (
                    <div class="venmo-checkout-message">
                      {content.windowMessage}
                    </div>
                  )}
                  {content.continueMessage && (
                    <div class="venmo-checkout-continue">
                      {/* This handler should be guarded with e.stopPropagation. 
                          This will stop the event from bubbling up to the overlay click handler
                          and causing unexpected behavior. */}
                      <a onClick={focusCheckout} href="#">
                        {content.continueMessage}
                      </a>
                    </div>
                  )}
                  {content.cancelMessage && !hideCloseButton && (
                    <div class="venmo-checkout-close">
                      <a
                        href="#"
                        onClick={closeCheckout}
                        onRender={(el) => {
                          closeButtonEl = el;
                        }}
                        aria-label="close"
                      >
                        {content.cancelMessage}
                      </a>
                    </div>
                  )}
                  <div class="venmo-checkout-loader">
                    <div class="venmo-spinner" />
                  </div>
                </div>
              )}
              <div
                class={
                  fullScreen
                    ? "venmo-checkout-iframe-container-full"
                    : "venmo-checkout-iframe-container"
                }
              >
                {outlet}
              </div>

              <style nonce={nonce}>{getVenmoContainerStyle({ uid })}</style>
            </div>
          </body>
        </html>
      </iframe>
    </div>
  );
}
