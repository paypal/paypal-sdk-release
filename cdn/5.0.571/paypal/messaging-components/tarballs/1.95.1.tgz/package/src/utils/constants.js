export const OFFER = {
    PAY_LATER_LONG_TERM: 'PAY_LATER_LONG_TERM',
    PAY_LATER_SHORT_TERM: 'PAY_LATER_SHORT_TERM',
    PAY_LATER_PAY_IN_1: 'PAY_LATER_PAY_IN_1',
    PAYPAL_CREDIT_NO_INTEREST: 'PAYPAL_CREDIT_NO_INTEREST',
    PAY_LATER: 'PAY_LATER',
    REWARDS: 'REWARDS'
};

export const TAG = {
    MESSAGE: 'paypal-message',
    MODAL: 'paypal-credit-modal',
    TREATEMENTS: 'paypal-credit-treatments',
    // Prevent messaging treatments from running inside buttons iframe (avoids duplicate /experiments/local + /hash)
    BUTTONS: 'paypal-buttons'
};
