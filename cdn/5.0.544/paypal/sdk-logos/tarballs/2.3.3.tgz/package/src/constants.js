/* @flow */

export const LOGO = {
  PP: ("pp": "pp"),
  PPMONOCHROME: ("ppmonochrome": "ppmonochrome"),
  PAYPAL: ("paypal": "paypal"),
  CARD: ("card": "card"),
  BANK: ("bank": "bank"),
  VENMO: ("venmo": "venmo"),
  APPLEPAY: ("applepay": "applepay"),
  ITAU: ("itau": "itau"),
  CREDIT: ("credit": "credit"),
  IDEAL: ("ideal": "ideal"),
  ELV: ("elv": "elv"),
  SEPA: ("sepa": "sepa"),
  BANCONTACT: ("bancontact": "bancontact"),
  GIROPAY: ("giropay": "giropay"),
  SOFORT: ("sofort": "sofort"),
  EPS: ("eps": "eps"),
  MYBANK: ("mybank": "mybank"),
  P24: ("p24": "p24"),
  WECHATPAY: ("wechatpay": "wechatpay"),
  PAYU: ("payu": "payu"),
  BLIK: ("blik": "blik"),
  TRUSTLY: ("trustly": "trustly"),
  OXXO: ("oxxo": "oxxo"),
  BOLETO: ("boleto": "boleto"),
  BOLETOBANCARIO: ("boletobancario": "boletobancario"),
  MERCADOPAGO: ("mercadopago": "mercadopago"),
  MULTIBANCO: ("multibanco": "multibanco"),
  SATISPAY: ("satispay": "satispay"),
  PAIDY: ("paidy": "paidy"),
  PAYPAL_REBRAND: ("paypal-rebrand": "paypal-rebrand"),
  VENMO_REBRAND: ("venmo-rebrand": "venmo-rebrand"),
  PP_REBRAND: ("pp-rebrand": "pp-rebrand"),
  CARD_REBRAND: ("card-rebrand": "card-rebrand"),
};

export const MARK = {
  APPLEPAY: ("applepay-mark": "applepay-mark"),
  CREDIT: ("credit-mark": "credit-mark"),
  CREDIT_REBRAND: ("credit-rebrand-mark": "credit-rebrand-mark"),
  PAYPAL: ("paypal-mark": "paypal-mark"),
  PAYLATER_REBRAND: ("paylater-rebrand-mark": "paylater-rebrand-mark"),
  BANCONTACT_REBRAND: ("bancontact-rebrand-mark": "bancontact-rebrand-mark"),
};

export const LOGO_COLOR = {
  BLUE: ("blue": "blue"),
  BLACK: ("black": "black"),
  WHITE: ("white": "white"),
  MONOCHROME: ("monochrome": "monochrome"),
  DEFAULT: ("default": "default"),
};

export const LOGO_CLASS = {
  LOGO: ("paypal-logo": "paypal-logo"),
  CARD: ("paypal-logo-card": "paypal-logo-card"),
  LOGO_COLOR: ("paypal-logo-color": "paypal-logo-color"),
};

const PACKAGE_VERSION = "2.3.3";
export const CDN_BASE_URL = `https://www.paypalobjects.com/js-sdk-logos/${PACKAGE_VERSION}`;
