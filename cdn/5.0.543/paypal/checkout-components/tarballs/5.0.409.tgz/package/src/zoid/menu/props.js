/* @flow */

export type MenuProps = {||};
