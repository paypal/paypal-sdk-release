/* @flow */

export const BUTTON_LABEL = {
  PAYPAL: ("paypal": "paypal"),
  CHECKOUT: ("checkout": "checkout"),
  BUYNOW: ("buynow": "buynow"),
  PAY: ("pay": "pay"),
  INSTALLMENT: ("installment": "installment"),
  SUBSCRIBE: ("subscribe": "subscribe"),
  DONATE: ("donate": "donate"),
};

export const BUTTON_COLOR = {
  DEFAULT: ("default": "default"),
  GOLD: ("gold": "gold"),
  BLUE: ("blue": "blue"),
  SILVER: ("silver": "silver"),
  DARKBLUE: ("darkblue": "darkblue"),
  BLACK: ("black": "black"),
  WHITE: ("white": "white"),
};

export const TEXT_COLOR = {
  BLACK: ("black": "black"),
  WHITE: ("white": "white"),
  DEFAULT: ("default": "default"),
};

export const BUTTON_SIZE = {
  TINY: ("tiny": "tiny"),
  SMALL: ("small": "small"),
  MEDIUM: ("medium": "medium"),
  LARGE: ("large": "large"),
  HUGE: ("huge": "huge"),
  RESPONSIVE: ("responsive": "responsive"),
};

export const BUTTON_REDESIGN_SIZE = {
  EXTRA_SMALL: ("extraSmall": "extraSmall"),
  TINY: ("tiny": "tiny"),
  SMALL: ("small": "small"),
  MEDIUM_SMALL: ("mediumSmall": "mediumSmall"),
  MEDIUM_BIG: ("mediumBig": "mediumBig"),
  LARGE_SMALL: ("largeSmall": "largeSmall"),
  LARGE_BIG: ("largeBig": "largeBig"),
  XL_SMALL: ("xlSmall": "xlSmall"),
  XL_BIG: ("xlBig": "xlBig"),
  XXL: ("xxl": "xxl"),
};

export const BUTTON_DISABLE_MAX_HEIGHT_SIZE = {
  TINY: ("tiny": "tiny"),
  SMALL: ("small": "small"),
  MEDIUM_SMALL: ("mediumSmall": "mediumSmall"),
  MEDIUM_BIG: ("mediumBig": "mediumBig"),
  LARGE_SMALL: ("largeSmall": "largeSmall"),
  LARGE_BIG: ("largeBig": "largeBig"),
  XL: ("xl": "xl"),
  XXL: ("xxl": "xxl"),
  XXXL: ("xxxl": "xxxl"),
};

export const BUTTON_SHAPE = {
  PILL: ("pill": "pill"),
  RECT: ("rect": "rect"),
  SHARP: ("sharp": "sharp"),
};

export const BUTTON_LAYOUT = {
  HORIZONTAL: ("horizontal": "horizontal"),
  VERTICAL: ("vertical": "vertical"),
};

export const BUTTON_NUMBER = {
  SINGLE: ("single": "single"),
  MULTIPLE: ("multiple": "multiple"),
};

export const BUTTON_FLOW = {
  PURCHASE: ("purchase": "purchase"),
  BILLING_SETUP: ("billing_setup": "billing_setup"),
  SUBSCRIPTION_SETUP: ("subscription_setup": "subscription_setup"),
  FULL_STACK_SUBSCRIPTION_SETUP:
    ("full_stack_subscription_setup": "full_stack_subscription_setup"),
  VAULT_WITHOUT_PURCHASE: ("vault_without_purchase": "vault_without_purchase"),
};

export const MENU_PLACEMENT = {
  ABOVE: ("above": "above"),
  BELOW: ("below": "below"),
};

export const MESSAGE_OFFER = {
  PAY_LATER_LONG_TERM: ("pay_later_long_term": "pay_later_long_term"),
  PAY_LATER_SHORT_TERM: ("pay_later_short_term": "pay_later_short_term"),
};

export const MESSAGE_COLOR = {
  BLACK: ("black": "black"),
  WHITE: ("white": "white"),
};

export const MESSAGE_POSITION = {
  TOP: ("top": "top"),
  BOTTOM: ("bottom": "bottom"),
};

export const MESSAGE_ALIGN = {
  CENTER: ("center": "center"),
  LEFT: ("left": "left"),
  RIGHT: ("right": "right"),
};

// Mark variation options (generic for future funding source support)
export const MARK_VARIATIONS = {
  WORDMARK: ("wordmark": "wordmark"),
  MONOGRAM: ("monogram": "monogram"),
};

export const BROWSER_CONTEXT = {
  BROWSER: ("browser": "browser"),
  WEBVIEW: ("webview": "webview"),
  ANDROID_CUSTOM_TAB: ("custom_tab": "custom_tab"),
  AS_WEB_AUTH_SESSION: ("as_web_auth_session": "as_web_auth_session"),
  SAFARI_VIEW_CONTROLLER: ("safari_view_controller": "safari_view_controller"),
  UNKNOWN: ("unknown": "unknown"),
};
