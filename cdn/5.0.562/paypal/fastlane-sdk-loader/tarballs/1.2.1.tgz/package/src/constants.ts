const CDNX_PROD = "https://www.paypalobjects.com";

const ASSET_NAME = {
  minified: "axo.min",
  unminified: "axo",
};

export const FL_NAMESPACE = "fastlane";

const ASSET_PATH = "connect-boba";

const LOCALE_PATH = `${ASSET_PATH}/locales/`;

export const constants = {
  AXO_ASSET_NAME: ASSET_NAME,
  AXO_ASSET_PATH: ASSET_PATH,
  LOCALE_PATH,
  CDNX_PROD,
} as const;
