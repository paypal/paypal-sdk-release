/**
 * Checks if the current environment is an AMD environment.
 *
 * @returns {boolean} True if the environment is AMD, false otherwise.
 */
export function isAmdEnv() {
  return typeof window.define === "function" && !!window.define.amd;
}

/**
 * Checks if the current environment is a RequireJS environment.
 *
 * @returns {boolean} True if the environment is RequireJS, false otherwise.
 */
export function isRequireJsEnv() {
  return (
    isAmdEnv() &&
    typeof window.requirejs === "function" &&
    typeof window.requirejs.config === "function"
  );
}
