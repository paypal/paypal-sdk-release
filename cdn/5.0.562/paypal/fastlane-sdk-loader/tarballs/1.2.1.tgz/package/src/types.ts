type LoadAxoOptionsMetaData = {
  bundleIdOverride?: string;
};

export type GenerateAssetUrl = {
  assetUrl: string;
  bundleId?: string;
};

export type LoadAxoOptions = {
  platform: AxoSupportedPlatform;
  btSdkVersion: string;
  minified?: boolean;
  metadata?: LoadAxoOptionsMetaData;
};

export const AxoSupportedPlatforms = {
  BT: "BT",
  PPCP: "PPCP",
} as const;

export type AxoSupportedPlatform = keyof typeof AxoSupportedPlatforms;

declare global {
  interface Window {
    define: () => void & {
      amd?: object;
    };
    requirejs?: Require;
    require?: (
      modules: string[],
      ready?: () => void,
      errback?: () => void
    ) => void;
  }
}
