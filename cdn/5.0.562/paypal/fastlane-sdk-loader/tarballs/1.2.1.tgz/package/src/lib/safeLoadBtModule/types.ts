/**
 * Maps to the BT module namespace created on the window.braintree object
 */
export const BtModule = {
  Client: "client",
  HostedCardFields: "hostedFields",
} as const;

export type BtModuleKeys = (typeof BtModule)[keyof typeof BtModule];

export type BtModuleLoadConfig = {
  id: string;
  module: BtModuleKeys;
  amdModule: {
    unminified: string;
    minified: string;
  };
  script: {
    unminified: string;
    minified: string;
  };
};

export const BT_NAMESPACE = "braintree";

export const BT_ASSET_NAME = {
  [BtModule.Client]: "client",
  [BtModule.HostedCardFields]: "hosted-fields",
} as const;

export const btModulesLoadConfig: Record<BtModuleKeys, BtModuleLoadConfig> = {
  [BtModule.Client]: {
    id: "client",
    module: BtModule.Client,
    amdModule: {
      unminified: `${BT_NAMESPACE}/${BT_ASSET_NAME[BtModule.Client]}`,
      minified: `${BT_NAMESPACE}/${BT_ASSET_NAME[BtModule.Client]}.min`,
    },
    script: {
      unminified: `${BT_ASSET_NAME[BtModule.Client]}.js`,
      minified: `${BT_ASSET_NAME[BtModule.Client]}.min.js`,
    },
  },
  [BtModule.HostedCardFields]: {
    id: "hcf",
    module: BtModule.HostedCardFields,
    amdModule: {
      unminified: `${BT_NAMESPACE}/${BT_ASSET_NAME[BtModule.HostedCardFields]}`,
      minified: `${BT_NAMESPACE}/${
        BT_ASSET_NAME[BtModule.HostedCardFields]
      }.min`,
    },
    script: {
      unminified: `${BT_ASSET_NAME[BtModule.HostedCardFields]}.js`,
      minified: `${BT_ASSET_NAME[BtModule.HostedCardFields]}.min.js`,
    },
  },
};
