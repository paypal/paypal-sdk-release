module.exports = require("./dist/load-axo-script");
