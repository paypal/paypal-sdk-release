# CHANGELOG

**This is the changelog for v1.x.x, which loads AXO SDK v0.6 (boba).**

## 1.2.1

- Revert minified and unminified values to load bundles from old URLs
  - See [DTXOUP-5754](https://paypal.atlassian.net/browse/DTXOUP-5754)

## 1.2.0

- Update minified and unminified values to load bundles from the new URLs
  - See [DTXOUP-5581](https://paypal.atlassian.net/browse/DTXOUP-5581)

## ⚠️ 1.1.1

Exact same code as `1.1.0-beta.1`. We needed to republish with a version `x.x.x` per a dependency version check in PP v5 SDK. See [this](https://github.com/krakenjs/grabthar/blob/main/src/npm.js#L362C10-L362C34) line of code
This should only be used until we have resolved the peer dependency issue in PP v5 sdk.

## ⚠️ 1.1.0-beta.1

Uses a modified version of `asset-loader` without Promises polyfill to unblock us tmp from publishing PP v5 SDK w/ AXO. See [slack thread](https://paypal.slack.com/archives/C04FBV3163E/p1701287607895859) for more details.
This should only be used until we have resolved the peer dependency issue in PP v5 sdk.

- [#19](https://github.com/OnePayPal/fastlane-sdk-loader/pull/19) Uses a modified version of `asset-loader` without Promises polyfill to unblock us tmp from publishing PP v5 SDK w/ AXO.

## 1.1.0

- [#18](https://github.com/OnePayPal/fastlane-sdk-loader/pull/18) Adds support for loading PPCP & BT

## 1.0.0 (Deprecated)

Deprecated as the version

- [#16](https://github.com/OnePayPal/fastlane-sdk-loader/pull/16) chore: update changelog and README
- [#17](https://github.com/OnePayPal/fastlane-sdk-loader/pull/17) chore: update version to boba

## 0.4.0

- [#12](https://github.com/OnePayPal/fastlane-sdk-loader/pull/12) fixes typo
- [#13](https://github.com/OnePayPal/fastlane-sdk-loader/pull/13) chore(update): update package lock

## 0.3.0

- [#8](https://github.com/OnePayPal/fastlane-sdk-loader/pull/8) feat(asseturl): add bundleid override and test
- [#9](https://github.com/OnePayPal/fastlane-sdk-loader/pull/9) Return locales url
- [#10](https://github.com/OnePayPal/fastlane-sdk-loader/pull/10) feature(hcf): add hcf loader

## 0.2.0

- [#4](https://github.com/OnePayPal/fastlane-sdk-loader/pull/4) rename connect-loader-component
- [#5](https://github.com/OnePayPal/fastlane-sdk-loader/pull/5) paypalcorp to paypal
- [#6](https://github.com/OnePayPal/fastlane-sdk-loader/pull/6) uses connect namespace

## 0.0.2

- [#2](https://github.com/OnePayPal/fastlane-sdk-loader/pull/2) Make Module Publishable to NPM
- [#3](https://github.com/OnePayPal/fastlane-sdk-loader/pull/3) Load axo prod assets for v0

## 0.0.1

- Initial version
