# fastlane-sdk-loader

Provides a static asset loader to fetch the latest PayPal Accelerated-Checkout components.

**This version (1.x.x) loads AXO SDK v0.6 (boba).**

## Installation

`npm install -S @paypal/fastlane-sdk-loader`

**Minified**

Serves the minified version of the AXO script.

```js
import { loadAxo } from "@paypal/fastlane-sdk-loader/dist/loader.esm";

loadAxo({ minified: true })
  .then(() => {
    console.log("minified script loaded");
    return;
  })
  .catch((err) => {
    console.log("There was an error: ", err);
  });
```

If no options are passed, the minified script is served by default

```js
import { loadAxo } from "@paypal/fastlane-sdk-loader/dist/loader.esm";

loadAxo()
  .then(() => {
    console.log("minified script loaded");
    return;
  })
  .catch((err) => {
    console.log("There was an error: ", err);
  });
```

**Unminified**

Serves the unminified version of the AXO script.

```js
import { loadAxo } from "@paypal/fastlane-sdk-loader/dist/loader.esm";

loadAxo({ minified: false })
  .then(() => {
    console.log("script loaded");
    return;
  })
  .catch((err) => {
    console.log("There was an error: ", err);
  });
```

## Testing

In order to test our accelerated checkout loader, we'll need to install [braintree.js](github.braintreeps.com) repo locally, which creates the final connect.js build for us to be consumed by accelerated checkout.

Run `npm link` in the `fastlane-sdk-loader` folder, then in the braintree repo, install node_modules and then `npm run build`. This should create a `connect.js` file under `dist/hosted/web/{VERSION}`, which should include your loader changes.

Now you can either stage it using web stage or just store it locally to be replaced wherever you were originally calling the connect file.
