"use strict";

exports.__esModule = true;
exports.unpackSDKMeta = unpackSDKMeta;
var _url = _interopRequireDefault(require("url"));
var _sdkConstants = require("@paypal/sdk-constants");
var _jsxPragmatic = require("@krakenjs/jsx-pragmatic");
var _constants = require("./constants");
var _util = require("./util");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
const emailRegex = /^.+@.+$/;
const semverRegex = /^[0-9.A-Za-z-+]+$/;
const dataAttributeNameRegex = /^data-[0-9A-Za-z-]+$/;
const webSDKPathRegex = /^\/web-sdk\/v([^/]+)\/bridge(\/[0-9A-Za-z-]+)*$/;
function validatePaymentsSDKUrl({
  pathname,
  query,
  hash
}) {
  if (pathname !== _sdkConstants.SDK_PATH) {
    throw new Error(`Invalid path for sdk url: ${pathname || "undefined"}`);
  }
  for (const [key, val] of (0, _util.entries)(query)) {
    if (!(0, _util.constHas)(_sdkConstants.SDK_QUERY_KEYS, key)) {
      throw new Error(`Unexpected query key for sdk url: ${key}`);
    }
    if (!val) {
      throw new Error(`Unexpected empty query value for sdk url: ${key}`);
    }
    if (typeof val !== "string") {
      throw new TypeError(`Unexpected non-string key for sdk url: ${key}`);
    }
    if (!val.match(/^[a-zA-Z0-9+_,-@.]+$/) && !val.match(/^\*$/)) {
      throw new Error(`Unexpected characters in query key for sdk url: ${key}=${val}`);
    }
    if (key === _sdkConstants.SDK_QUERY_KEYS.MERCHANT_ID && val.includes("@")) {
      const merchantValues = val.split(",");
      merchantValues.forEach(merchantValue => {
        if (merchantValue.length > 320) {
          throw new Error(`Email is too long: ${merchantValue}`);
        }
        if (!emailRegex.test(merchantValue)) {
          throw new Error(`Malformed. merchant email: ${merchantValue}`);
        }
      });
    }
  }
  if (hash) {
    throw new Error(`Expected no hash to be passed in sdk url, got ${hash}`);
  }
}
function validateLegacySDKUrl({
  pathname
}) {
  if (!pathname.match(_constants.LEGACY_SDK_PATH)) {
    throw new Error(`Invalid path for legacy sdk url: ${pathname || "undefined"}`);
  }
}
function validateWebSDKUrl({
  pathname
}) {
  const match = pathname.match(webSDKPathRegex);
  if (!match) {
    throw new Error(`Invalid path for web-sdk bridge url: ${pathname || "undefined"}`);
  }
  const version = match[1];
  if (!semverRegex.test(version)) {
    throw new Error(`Invalid version for web-sdk bridge url: ${version}`);
  }
}
function isLegacySDKUrl(hostname, pathname) {
  const legacyHostnames = [_constants.HOST.PAYPALOBJECTS, _constants.HOST.PAYPALOBJECTS_CHINA];
  if (legacyHostnames.includes(hostname)) {
    return true;
  }
  const validHostnameEndings = [_constants.HOST.PAYPAL, _constants.HOST.PAYPAL_CHINA, _constants.HOST.PAYPALOBJECTS_QA];
  const isValidHostname = validHostnameEndings.some(validHostname => hostname.endsWith(validHostname));
  if (isValidHostname && pathname.match(_constants.LEGACY_SDK_PATH)) {
    return true;
  }
  return false;
}
function isSDKUrl(hostname) {
  if (hostname.endsWith(_constants.HOST.PAYPAL) || hostname.endsWith(_constants.HOST.PAYPAL_CHINA)) {
    return true;
  }
  return false;
}
function isWebSDKUrl(hostname, pathname) {
  if (isSDKUrl(hostname) && pathname.startsWith(_constants.WEB_SDK_PATH)) {
    return true;
  }
  return false;
}
function isLocalUrl(host) {
  const localUrls = [_constants.HOST.LOCALHOST_8000, _constants.HOST.LOCALHOST_8443, _constants.HOST.LOCALTUNNEL];
  return process.env.NODE_ENV === "development" && localUrls.some(url => host.includes(url));
}
function validateHostAndPath(hostname, pathname) {
  if (!pathname || !hostname) {
    throw new Error(`Expected host and pathname to be passed for sdk url`);
  }
  return {
    hostname,
    pathname
  };
}
function validateSDKUrl(sdkUrl) {
  const {
    protocol,
    host,
    hostname: sourceHostname,
    pathname: sourcePathname,
    query,
    hash
  } = _url.default.parse(sdkUrl, true);
  const {
    hostname,
    pathname
  } = validateHostAndPath(sourceHostname, sourcePathname);
  if (!sdkUrl.startsWith(_constants.PROTOCOL.HTTP) && !sdkUrl.startsWith(_constants.PROTOCOL.HTTPS)) {
    throw new Error(`Expected protocol for sdk url to be ${_constants.PROTOCOL.HTTP} or ${_constants.PROTOCOL.HTTPS} for host: ${hostname} - got ${protocol || "undefined"}`);
  }
  const hostnameMatchResults = hostname.match(/[a-z0-9\.\-]+/);
  if (!hostnameMatchResults || hostnameMatchResults[0] !== hostname) {
    throw new Error(`Expected a valid host: ${hostname}`);
  }
  if (isLegacySDKUrl(hostname, pathname)) {
    validateLegacySDKUrl({
      pathname
    });
  } else if (isWebSDKUrl(hostname, pathname)) {
    validateWebSDKUrl({
      pathname
    });
  } else if (isSDKUrl(hostname)) {
    if (hostname !== _constants.HOST.LOCALHOST && protocol !== _constants.PROTOCOL.HTTPS) {
      throw new Error(`Expected protocol for sdk url to be ${_constants.PROTOCOL.HTTPS} for host: ${hostname} - got ${protocol || "undefined"}`);
    }
    if (sdkUrl.match(/&{2,}/) || sdkUrl.match(/&$/)) {
      throw new Error(`Expected sdk url to not contain double ampersand or end in ampersand`);
    }
    validatePaymentsSDKUrl({
      protocol,
      hostname,
      pathname,
      query,
      hash
    });
  } else if (host && !isLocalUrl(host)) {
    throw new Error(`Expected host to be a subdomain of ${_constants.HOST.PAYPAL} or ${_constants.HOST.PAYPALOBJECTS}`);
  }
}
const getDefaultSDKAttributes = () => {
  return {};
};
function getSDKScriptAttributes(sdkUrl, allAttrs) {
  const attrs = getDefaultSDKAttributes();
  if (sdkUrl) {
    const {
      hostname: sourceHostname,
      pathname: sourcePathname
    } = _url.default.parse(sdkUrl, true);
    const {
      hostname,
      pathname
    } = validateHostAndPath(sourceHostname, sourcePathname);
    if (isLegacySDKUrl(hostname, pathname)) {
      attrs[_constants.DATA_ATTRIBUTES.PAYPAL_CHECKOUT] = true;
      attrs[_constants.DATA_ATTRIBUTES.NO_BRIDGE] = true;
    }
    if (isWebSDKUrl(hostname, pathname)) {
      attrs[_constants.DATA_ATTRIBUTES.SDK_META_CONTRACT_VERSION] = _constants.VERSION;
    }
  }
  for (const name in allAttrs) {
    if (dataAttributeNameRegex.test(name)) {
      attrs[name] = allAttrs[name];
    }
  }
  return attrs;
}
function sanitizeSDKUrl(sdkUrl) {
  const url = new URL(sdkUrl);
  if (isLegacySDKUrl(url.hostname, url.pathname)) {
    url.search = "";
    url.hash = "";
    return url.toString();
  }
  return sdkUrl;
}
function unpackSDKMeta(sdkMeta) {
  const {
    url,
    attrs
  } = sdkMeta ? JSON.parse(Buffer.from(decodeURIComponent(sdkMeta), "base64").toString("utf8")) : _constants.DEFAULT_SDK_META;
  if (url) {
    validateSDKUrl(url);
  }
  const getSDKLoader = ({
    baseURL = _constants.DEFAULT_LEGACY_SDK_BASE_URL,
    nonce = ""
  } = {}) => {
    if (url) {
      const validAttrs = getSDKScriptAttributes(url, attrs);
      const allAttrs = {
        nonce,
        src: sanitizeSDKUrl(url),
        ...validAttrs
      };
      return (0, _jsxPragmatic.node)("script", allAttrs).render((0, _jsxPragmatic.html)());
    }
    return (0, _jsxPragmatic.node)("script", {
      nonce: nonce,
      innerHTML: `
                    (function() {
                        function loadScript(url, attributes) {
                            var scriptTag = '<scr' + 'ipt src="' + url + '" ' + (attributes || '') + '></scr' + 'ipt>';
                            document.write(scriptTag);
                        }

                        function loadV4() {
                            if (!window.name || window.name.indexOf('xcomponent') !== 0) {
                                return;
                            }

                            var version = window.name.split('__')[2].replace(/_/g, '.');

                            if (!version.match(/^[0-9a-zA-Z.]+$/)) {
                                return;
                            }

                            if (version === '4' || version === 'latest') {
                                version = '';
                            }

                            var url = '${baseURL}checkout' + (version ? ('.' + version) : '') + '.js';
                            var attributes = '${_constants.DATA_ATTRIBUTES.PAYPAL_CHECKOUT} ${_constants.DATA_ATTRIBUTES.NO_BRIDGE}';

                            loadScript(url, attributes);
                        }

                        function loadV5() {
                            var ancestor = (window.parent && window.parent !== window)
                                ? window.parent
                                : window.opener;

                            if (!ancestor || !ancestor.document) {
                                return;
                            }

                            var v5script = ancestor.document.querySelector('script[src*="/sdk/js"]');

                            if (!v5script || !v5script.src) {
                                return;
                            }

                            loadScript(v5script.src);
                        }

                        try {
                            if (window.paypal && window.paypal.version) {
                                return;
                            }

                            loadV4();
                            loadV5();
                        } catch (err) {
                            return;
                        }
                    })();
                `
    }).render((0, _jsxPragmatic.html)());
  };
  return {
    getSDKLoader
  };
}