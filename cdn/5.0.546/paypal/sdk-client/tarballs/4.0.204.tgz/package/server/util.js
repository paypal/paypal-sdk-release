"use strict";

exports.__esModule = true;
exports.constHas = void 0;
exports.entries = entries;
var _belter = require("@krakenjs/belter");
const constHas = (constant, value) => {
  return (0, _belter.memoizedValues)(constant).indexOf(value) !== -1;
};
exports.constHas = constHas;
function entries(obj) {
  const result = [];
  for (const key of Object.keys(obj)) {
    result.push([key, obj[key]]);
  }
  return result;
}