"use strict";

exports.__esModule = true;
exports.WEB_SDK_PATH = exports.VERSION = exports.PROTOCOL = exports.LEGACY_SDK_PATH = exports.HOST = exports.DEFAULT_SDK_META = exports.DEFAULT_LEGACY_SDK_BASE_URL = exports.DATA_ATTRIBUTES = void 0;
var _package = require("../package.json");
const VERSION = exports.VERSION = _package.version;
const HOST = exports.HOST = {
  LOCALHOST: "localhost.paypal.com",
  PAYPAL: ".paypal.com",
  PAYPAL_CHINA: ".paypal.cn",
  PAYPALOBJECTS: "www.paypalobjects.com",
  PAYPALOBJECTS_CHINA: "objects.paypal.cn",
  PAYPALOBJECTS_QA: ".paypalinc.com",
  LOCALTUNNEL: "loca.lt",
  LOCALHOST_8000: "localhost:8000",
  LOCALHOST_8443: "localhost:8443"
};
const PROTOCOL = exports.PROTOCOL = {
  HTTP: "http:",
  HTTPS: "https:"
};
const LEGACY_SDK_PATH = exports.LEGACY_SDK_PATH = /^(\/[a-zA-Z0-9_-]+)*\/checkout(\.4\.0\.\d{1,3})?(\.min)?\.js$/;
const WEB_SDK_PATH = exports.WEB_SDK_PATH = "/web-sdk/";
const DEFAULT_SDK_META = exports.DEFAULT_SDK_META = {
  url: "",
  attrs: {
    "data-stage-host": "",
    "data-api-stage-host": ""
  }
};
const DEFAULT_LEGACY_SDK_BASE_URL = exports.DEFAULT_LEGACY_SDK_BASE_URL = "https://www.paypalobjects.com/api/";
const DATA_ATTRIBUTES = exports.DATA_ATTRIBUTES = {
  PAYPAL_CHECKOUT: "data-paypal-checkout",
  NO_BRIDGE: "data-no-bridge",
  SDK_META_CONTRACT_VERSION: "data-sdk-meta-contract-version"
};