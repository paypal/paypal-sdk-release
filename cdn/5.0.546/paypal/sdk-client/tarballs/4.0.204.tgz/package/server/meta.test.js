"use strict";

var _cheerio = _interopRequireDefault(require("cheerio"));
var _vitest = require("vitest");
var _constants = require("./constants");
var _ = require(".");
function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
(0, _vitest.afterEach)(() => {
  process.env.NODE_ENV = "test";
});
(0, _vitest.test)("should construct a valid script url", () => {
  const sdkUrl = "https://www.paypal.com/sdk/js?client-id=foo";
  const {
    getSDKLoader
  } = (0, _.unpackSDKMeta)(Buffer.from(JSON.stringify({
    url: sdkUrl
  })).toString("base64"));
  const $ = _cheerio.default.load(getSDKLoader());
  const src = $("script").attr("src");
  if (src !== sdkUrl) {
    throw new Error(`Expected script url to be ${sdkUrl} - got ${src}`);
  }
});
(0, _vitest.test)("should construct a valid script url with data-popups-disabled attribute", () => {
  const sdkUrl = "https://www.paypal.com/sdk/js?client-id=foo";
  const {
    getSDKLoader
  } = (0, _.unpackSDKMeta)(Buffer.from(JSON.stringify({
    url: sdkUrl,
    attrs: {
      "data-popups-disabled": "true"
    }
  })).toString("base64"));
  const $ = _cheerio.default.load(getSDKLoader());
  const dataPopUsDisabled = $("script").attr("data-popups-disabled");
  if (dataPopUsDisabled !== "true") {
    throw new Error(`Expected dataPopUsDisabled to be true  - got ${dataPopUsDisabled}`);
  }
});
(0, _vitest.test)("should construct a valid script url with paypalobjects", () => {
  const sdkUrl = "https://www.paypalobjects.com/api/checkout.js";
  const {
    getSDKLoader
  } = (0, _.unpackSDKMeta)(Buffer.from(JSON.stringify({
    url: sdkUrl
  })).toString("base64"));
  const $ = _cheerio.default.load(getSDKLoader());
  const script = $("script[data-paypal-checkout]");
  const src = script.attr("src");
  if (src !== sdkUrl) {
    throw new Error(`Expected script url to be ${sdkUrl} - got ${src}`);
  }
});
(0, _vitest.test)("should construct a valid script url with url encoded sdkMeta and trailing ? in checkout.js", () => {
  const sdkUrl = "https://www.paypalobjects.com/api/checkout.js?";
  const {
    getSDKLoader
  } = (0, _.unpackSDKMeta)(encodeURIComponent(Buffer.from(JSON.stringify({
    url: sdkUrl
  })).toString("base64")));
  const $ = _cheerio.default.load(getSDKLoader());
  const script = $("script[data-paypal-checkout]");
  const src = script.attr("src");
  if (src !== "https://www.paypalobjects.com/api/checkout.js") {
    throw new Error(`unexpected script url ${src}`);
  }
});
(0, _vitest.test)("should construct a valid script url with checkout.js using the qa cdn", () => {
  const sdkUrl = "https://uideploy--staticcontent--7482d416a81b5--ghe.preview.dev.paypalinc.com/api/checkout.js";
  const {
    getSDKLoader
  } = (0, _.unpackSDKMeta)(Buffer.from(JSON.stringify({
    url: sdkUrl
  })).toString("base64"));
  const $ = _cheerio.default.load(getSDKLoader());
  const script = $("script[data-paypal-checkout]");
  const src = script.attr("src");
  if (src !== sdkUrl) {
    throw new Error(`Expected script url to be ${sdkUrl} - got ${src}`);
  }
});
(0, _vitest.test)("should construct a valid script url with checkout.js on localhost", () => {
  const sdkUrl = "http://localhost.paypal.com:8000/api/checkout.js";
  const {
    getSDKLoader
  } = (0, _.unpackSDKMeta)(Buffer.from(JSON.stringify({
    url: sdkUrl
  })).toString("base64"));
  const $ = _cheerio.default.load(getSDKLoader());
  const script = $("script[data-paypal-checkout]");
  const src = script.attr("src");
  if (src !== sdkUrl) {
    throw new Error(`Expected script url to be ${sdkUrl} - got ${src}`);
  }
});
(0, _vitest.test)("should construct a script url with checkout.js on localhost without a paypal.com domain", () => {
  process.env.NODE_ENV = "development";
  const sdkUrl = "http://localhost:8000/api/checkout.js";
  let error;
  try {
    (0, _.unpackSDKMeta)(Buffer.from(JSON.stringify({
      url: sdkUrl
    })).toString("base64"));
  } catch (err) {
    error = err;
  }
  if (error) {
    throw new Error(`Should construct script with localhost url`);
  }
});
(0, _vitest.test)("should not construct a script url with checkout.js for non-supported local urls", () => {
  process.env.NODE_ENV = "development";
  const sdkUrl = "http://not.a.supported.url:8000/api/checkout.js";
  let error;
  try {
    (0, _.unpackSDKMeta)(Buffer.from(JSON.stringify({
      url: sdkUrl
    })).toString("base64"));
  } catch (err) {
    error = err;
  }
  if (!error) {
    throw new Error(`Should construct script with supported local urls: (localhost, loca.lt)`);
  }
});
(0, _vitest.test)("should construct a valid minified script url with paypalobjects", () => {
  const sdkUrl = "https://www.paypalobjects.com/api/checkout.min.js";
  const {
    getSDKLoader
  } = (0, _.unpackSDKMeta)(Buffer.from(JSON.stringify({
    url: sdkUrl
  })).toString("base64"));
  const $ = _cheerio.default.load(getSDKLoader());
  const script = $("script[data-paypal-checkout]");
  const src = script.attr("src");
  if (src !== sdkUrl) {
    throw new Error(`Expected script url to be ${sdkUrl} - got ${src}`);
  }
});
(0, _vitest.test)("should prevent query string parameters with checkout.js", () => {
  const sdkUrl = "https://www.sandbox.paypal.com/cgi-bin/webscr/checkout.js?cmd=_flow&CONTEXT=wtgSziM4oze46J3pBRQ";
  const {
    getSDKLoader
  } = (0, _.unpackSDKMeta)(Buffer.from(JSON.stringify({
    url: sdkUrl
  })).toString("base64"));
  const $ = _cheerio.default.load(getSDKLoader());
  const script = $("script[data-paypal-checkout]");
  const src = script.attr("src");
  const urlObject = new URL(sdkUrl);
  urlObject.search = "";
  const expectedUrl = urlObject.toString();
  if (src !== expectedUrl) {
    throw new Error(`Expected script url to be ${expectedUrl} - got ${src}`);
  }
});
(0, _vitest.test)("should construct a valid versioned script url with paypalobjects", () => {
  const sdkUrl = "https://www.paypalobjects.com/api/checkout.4.0.125.js";
  const {
    getSDKLoader
  } = (0, _.unpackSDKMeta)(Buffer.from(JSON.stringify({
    url: sdkUrl
  })).toString("base64"));
  const $ = _cheerio.default.load(getSDKLoader());
  const script = $("script[data-paypal-checkout]");
  const src = script.attr("src");
  if (src !== sdkUrl) {
    throw new Error(`Expected script url to be ${sdkUrl} - got ${src}`);
  }
});
(0, _vitest.test)("should construct a valid versioned minified script url with paypalobjects", () => {
  const sdkUrl = "https://www.paypalobjects.com/api/checkout.4.0.125.min.js";
  const {
    getSDKLoader
  } = (0, _.unpackSDKMeta)(Buffer.from(JSON.stringify({
    url: sdkUrl
  })).toString("base64"));
  const $ = _cheerio.default.load(getSDKLoader());
  const script = $("script[data-paypal-checkout]");
  const src = script.attr("src");
  if (src !== sdkUrl) {
    throw new Error(`Expected script url to be ${sdkUrl} - got ${src}`);
  }
});
(0, _vitest.test)("should construct a valid localhost script url", () => {
  const sdkUrl = "http://localhost.paypal.com:8000/sdk/js?client-id=foo";
  const {
    getSDKLoader
  } = (0, _.unpackSDKMeta)(Buffer.from(JSON.stringify({
    url: sdkUrl
  })).toString("base64"));
  const $ = _cheerio.default.load(getSDKLoader());
  const src = $("script").attr("src");
  if (src !== sdkUrl) {
    throw new Error(`Expected script url to be ${sdkUrl} - got ${src}`);
  }
});
(0, _vitest.test)("should unpack a valid sdk meta bundle with a component", () => {
  const sdkUrl = "https://www.paypal.com/sdk/js?client-id=foo&components=buttons";
  const {
    getSDKLoader
  } = (0, _.unpackSDKMeta)(Buffer.from(JSON.stringify({
    url: sdkUrl
  })).toString("base64"));
  const $ = _cheerio.default.load(getSDKLoader());
  const src = $("script").attr("src");
  if (src !== sdkUrl) {
    throw new Error(`Expected script url to be ${sdkUrl} - got ${src}`);
  }
});
(0, _vitest.test)("should unpack a valid sdk meta bundle with multiple components", () => {
  const sdkUrl = "https://www.paypal.com/sdk/js?client-id=foo&components=buttons,hosted-fields";
  const {
    getSDKLoader
  } = (0, _.unpackSDKMeta)(Buffer.from(JSON.stringify({
    url: sdkUrl
  })).toString("base64"));
  const $ = _cheerio.default.load(getSDKLoader());
  const src = $("script").attr("src");
  if (src !== sdkUrl) {
    throw new Error(`Expected script url to be ${sdkUrl} - got ${src}`);
  }
});
(0, _vitest.test)("should unpack a valid sdk meta bundle with multiple merchant-id email addresses", () => {
  const emails = ["test@gmail.com", "foo@bar.com", "test@test.org.uk", "test-test@test.com", "test.test@test.com", "test@test@test.com"];
  const sdkUrl = `https://www.paypal.com/sdk/js?client-id=foo&merchant-id=${emails.map(anEmail => encodeURIComponent(anEmail)).join(",")}`;
  const {
    getSDKLoader
  } = (0, _.unpackSDKMeta)(Buffer.from(JSON.stringify({
    url: sdkUrl
  })).toString("base64"));
  const $ = _cheerio.default.load(getSDKLoader());
  const src = $("script").attr("src");
  if (src !== sdkUrl) {
    throw new Error(`Expected script url to be ${sdkUrl} - got ${src}`);
  }
});
(0, _vitest.test)("should error out from invalid merchant-id email addresses", () => {
  const emails = ["@", "@io", "@test.com", "name@"];
  emails.forEach(email => {
    const sdkUrl = `https://www.paypal.com/sdk/js?client-id=foo&merchant-id=${email}`;
    let error;
    try {
      (0, _.unpackSDKMeta)(Buffer.from(JSON.stringify({
        url: sdkUrl
      })).toString("base64"));
    } catch (err) {
      error = err;
    }
    if (!error) {
      throw new Error(`Expected error to be thrown for ${sdkUrl}`);
    }
  });
});
(0, _vitest.test)("should error from very long merchant-id email addresses", () => {
  const longEmail = `${"a-very-long-email".repeat(20)}@a-very-long-domain.com`;
  const sdkUrl = `https://www.paypal.com/sdk/js?client-id=foo&merchant-id=${longEmail}`;
  let error;
  try {
    (0, _.unpackSDKMeta)(Buffer.from(JSON.stringify({
      url: sdkUrl
    })).toString("base64"));
  } catch (err) {
    error = err;
  }
  if (!error) {
    throw new Error(`Expected error to be thrown for ${sdkUrl}`);
  }
});
(0, _vitest.test)("should construct a valid script url with multiple merchant ids", () => {
  const sdkUrl = "https://www.paypal.com/sdk/js?client-id=foo";
  const merchantId = "abcd1234, abcd5678";
  const {
    getSDKLoader
  } = (0, _.unpackSDKMeta)(Buffer.from(JSON.stringify({
    url: sdkUrl,
    attrs: {
      "data-merchant-id": merchantId
    }
  })).toString("base64"));
  const $ = _cheerio.default.load(getSDKLoader());
  const src = $("script").attr("src");
  const dataMerchantId = $("script").attr("data-merchant-id");
  if (src !== sdkUrl) {
    throw new Error(`Expected script url to be ${sdkUrl} - got ${src}`);
  }
  if (dataMerchantId !== merchantId) {
    throw new Error(`Expected data-merchant-id to be ${merchantId} - got ${dataMerchantId}`);
  }
});
(0, _vitest.test)("should construct a valid script url with a single merchant id in the url", () => {
  const merchantId = "UYEGJNV75RAJQ";
  const sdkUrl = `https://www.paypal.com/sdk/js?client-id=foo&merchant-id=${merchantId}`;
  const {
    getSDKLoader
  } = (0, _.unpackSDKMeta)(Buffer.from(JSON.stringify({
    url: sdkUrl
  })).toString("base64"));
  const $ = _cheerio.default.load(getSDKLoader());
  const src = $("script").attr("src");
  if (src !== sdkUrl) {
    throw new Error(`Expected script url to be ${sdkUrl} - got ${src}`);
  }
});
(0, _vitest.test)("should construct a valid script url without invalid attributes", () => {
  const sdkUrl = "https://www.paypal.com/sdk/js?client-id=foo";
  const {
    getSDKLoader
  } = (0, _.unpackSDKMeta)(Buffer.from(JSON.stringify({
    url: sdkUrl,
    attrs: {
      "data-uid": "abc123",
      onload: "alert('xss')"
    }
  })).toString("base64"));
  const $ = _cheerio.default.load(getSDKLoader());
  const src = $("script").attr("src");
  const uid = $("script").attr("data-uid");
  const onload = $("script").attr("onload");
  if (src !== sdkUrl) {
    throw new Error(`Expected script url to be ${sdkUrl} - got ${src}`);
  }
  if (uid !== "abc123") {
    throw new Error(`Expected data-uid to be "abc123" - got ${uid}`);
  }
  if (onload !== undefined) {
    throw new Error(`Expected invalid attribute to be undefined - got ${onload}`);
  }
});
const previouslyAllowedAttrs = ["data-amount", "data-client-token", "data-merchant-id", "data-partner-attribution-id", "data-popups-disabled", "data-enable-3ds", "data-sdk-integration-source", "data-client-metadata-id", "data-uid", "data-csp-nonce"];
_vitest.test.each(previouslyAllowedAttrs)("should allow previously allowed attribute %s", attr => {
  const sdkUrl = "https://www.paypal.com/sdk/js?client-id=foo";
  const {
    getSDKLoader
  } = (0, _.unpackSDKMeta)(Buffer.from(JSON.stringify({
    url: sdkUrl,
    attrs: {
      [attr]: "test-value"
    }
  })).toString("base64"));
  const $ = _cheerio.default.load(getSDKLoader());
  const result = $("script").attr(attr);
  if (result !== "test-value") {
    throw new Error(`Expected ${attr} to be "test-value" - got ${result}`);
  }
});
(0, _vitest.test)("should encode unsafe characters in data attribute values", () => {
  const sdkUrl = "https://www.paypal.com/sdk/js?client-id=foo";
  const {
    getSDKLoader
  } = (0, _.unpackSDKMeta)(Buffer.from(JSON.stringify({
    url: sdkUrl,
    attrs: {
      "data-uid": "\" onload=\"alert('xss')"
    }
  })).toString("base64"));
  const $ = _cheerio.default.load(getSDKLoader());
  if ($("script").attr("onload") !== undefined) {
    throw new Error("Expected onload attribute to not be present");
  }
});
(0, _vitest.test)("should encode script tag injection in data attribute values", () => {
  const sdkUrl = "https://www.paypal.com/sdk/js?client-id=foo";
  const {
    getSDKLoader
  } = (0, _.unpackSDKMeta)(Buffer.from(JSON.stringify({
    url: sdkUrl,
    attrs: {
      "data-uid": "\"></script><script>alert('xss')</script><script src=\""
    }
  })).toString("base64"));
  const $ = _cheerio.default.load(getSDKLoader());
  if ($("script").length !== 1) {
    throw new Error(`Expected exactly 1 script element, got ${$("script").length}`);
  }
});
(0, _vitest.test)("should not allow attribute injection via spaces in data attribute name", () => {
  const sdkUrl = "https://www.paypal.com/sdk/js?client-id=foo";
  const {
    getSDKLoader
  } = (0, _.unpackSDKMeta)(Buffer.from(JSON.stringify({
    url: sdkUrl,
    attrs: {
      "data-x onload": "alert('xss')"
    }
  })).toString("base64"));
  const $ = _cheerio.default.load(getSDKLoader());
  if ($("script").attr("onload") !== undefined) {
    throw new Error("Expected onload attribute to not be present");
  }
});
(0, _vitest.test)("should error out with an unsecure protocol", () => {
  const sdkUrl = "http://www.paypal.com/sdk/js?client-id=foo&";
  let error;
  try {
    (0, _.unpackSDKMeta)(Buffer.from(JSON.stringify({
      url: sdkUrl
    })).toString("base64"));
  } catch (err) {
    error = err;
  }
  if (!error) {
    throw new Error(`Expected error to be thrown`);
  }
});
(0, _vitest.test)("should error out with an invalid protocol", () => {
  const sdkUrl = "meep://www.paypal.com/sdk/js?client-id=foo";
  let error;
  try {
    (0, _.unpackSDKMeta)(Buffer.from(JSON.stringify({
      url: sdkUrl
    })).toString("base64"));
  } catch (err) {
    error = err;
  }
  if (!error) {
    throw new Error(`Expected error to be thrown`);
  }
});
(0, _vitest.test)("should error out with an invalid protocol in localhost", () => {
  const sdkUrl = "meep://localhost.paypal.com:8000/sdk/js?client-id=foo";
  let error;
  try {
    (0, _.unpackSDKMeta)(Buffer.from(JSON.stringify({
      url: sdkUrl
    })).toString("base64"));
  } catch (err) {
    error = err;
  }
  if (!error) {
    throw new Error(`Expected error to be thrown`);
  }
});
(0, _vitest.test)("should error out with an invalid host", () => {
  const sdkUrl = "https://?client-id=foo";
  let error;
  try {
    (0, _.unpackSDKMeta)(Buffer.from(JSON.stringify({
      url: sdkUrl
    })).toString("base64"));
  } catch (err) {
    error = err;
  }
  if (!error) {
    throw new Error(`Expected error to be thrown`);
  }
});
(0, _vitest.test)("should error out with no path", () => {
  const sdkUrl = "https://www.paypal.com?client-id=foo";
  let error;
  try {
    (0, _.unpackSDKMeta)(Buffer.from(JSON.stringify({
      url: sdkUrl
    })).toString("base64"));
  } catch (err) {
    error = err;
  }
  if (!error) {
    throw new Error(`Expected error to be thrown`);
  }
});
(0, _vitest.test)("should error out with an invalid path", () => {
  const sdkUrl = "https://www.paypal.com/sdk/meep?client-id=foo";
  let error;
  try {
    (0, _.unpackSDKMeta)(Buffer.from(JSON.stringify({
      url: sdkUrl
    })).toString("base64"));
  } catch (err) {
    error = err;
  }
  if (!error) {
    throw new Error(`Expected error to be thrown`);
  }
});
(0, _vitest.test)("should error out with an invalid legacy path", () => {
  const sdkUrl = "https://www.paypalobjects.com/foo.js";
  let error;
  try {
    (0, _.unpackSDKMeta)(Buffer.from(JSON.stringify({
      url: sdkUrl
    })).toString("base64"));
  } catch (err) {
    error = err;
  }
  if (!error) {
    throw new Error(`Expected error to be thrown`);
  }
});
(0, _vitest.test)("should error out with an empty query param", () => {
  const sdkUrl = "https://www.paypal.com/sdk/js?client-id=";
  let error;
  try {
    (0, _.unpackSDKMeta)(Buffer.from(JSON.stringify({
      url: sdkUrl
    })).toString("base64"));
  } catch (err) {
    error = err;
  }
  if (!error) {
    throw new Error(`Expected error to be thrown`);
  }
});
(0, _vitest.test)("should error out with a duplicated query param", () => {
  const sdkUrl = "https://www.paypal.com/sdk/js?client-id=foo&client-id=bar";
  let error;
  try {
    (0, _.unpackSDKMeta)(Buffer.from(JSON.stringify({
      url: sdkUrl
    })).toString("base64"));
  } catch (err) {
    error = err;
  }
  if (!error) {
    throw new Error(`Expected error to be thrown`);
  }
});
(0, _vitest.test)("should error out with an invalid query param", () => {
  const sdkUrl = "https://www.paypal.com/sdk/js?client-id=foo&foo=bar";
  let error;
  try {
    (0, _.unpackSDKMeta)(Buffer.from(JSON.stringify({
      url: sdkUrl
    })).toString("base64"));
  } catch (err) {
    error = err;
  }
  if (!error) {
    throw new Error(`Expected error to be thrown`);
  }
});
(0, _vitest.test)("should error out with an invalid query value", () => {
  const sdkUrl = 'https://www.paypal.com/sdk/js?client-id="foo"';
  let error;
  try {
    (0, _.unpackSDKMeta)(Buffer.from(JSON.stringify({
      url: sdkUrl
    })).toString("base64"));
  } catch (err) {
    error = err;
  }
  if (!error) {
    throw new Error(`Expected error to be thrown`);
  }
});
(0, _vitest.test)("should error out with a hash", () => {
  const sdkUrl = "https://www.paypal.com/sdk/js?client-id=foo#bar";
  let error;
  try {
    (0, _.unpackSDKMeta)(Buffer.from(JSON.stringify({
      url: sdkUrl
    })).toString("base64"));
  } catch (err) {
    error = err;
  }
  if (!error) {
    throw new Error(`Expected error to be thrown`);
  }
});
(0, _vitest.test)("should construct a valid loader even when no url passed", () => {
  const sdkUrl = "https://www.paypalobjects.com/api/checkout.js";
  const {
    getSDKLoader
  } = (0, _.unpackSDKMeta)();
  const $ = _cheerio.default.load(getSDKLoader());
  const script = $("script").html();
  let scriptTag;
  const window = {
    name: "xcomponent__ppcheckout__latest__abc12345"
  };
  const document = {
    write: html => {
      scriptTag = html;
    }
  };
  eval(script);
  const $$ = _cheerio.default.load(scriptTag);
  const scriptz = $$("script[data-paypal-checkout]");
  const src = scriptz.attr("src");
  if (src !== sdkUrl) {
    throw new Error(`Expected script url to be ${sdkUrl} - got ${src}`);
  }
});
(0, _vitest.test)("should construct a valid minified loader even when no url passed", () => {
  const sdkUrl = "https://www.paypalobjects.com/api/checkout.min.js";
  const {
    getSDKLoader
  } = (0, _.unpackSDKMeta)();
  const $ = _cheerio.default.load(getSDKLoader());
  const script = $("script").html();
  let scriptTag;
  const window = {
    name: "xcomponent__ppcheckout__min__abc12345"
  };
  const document = {
    write: html => {
      scriptTag = html;
    }
  };
  eval(script);
  const $$ = _cheerio.default.load(scriptTag);
  const src = $$("script").attr("src");
  if (src !== sdkUrl) {
    throw new Error(`Expected script url to be ${sdkUrl} - got ${src}`);
  }
});
(0, _vitest.test)("should construct a valid version loader even when no url passed", () => {
  const sdkUrl = "https://www.paypalobjects.com/api/checkout.4.0.435.js";
  const {
    getSDKLoader
  } = (0, _.unpackSDKMeta)();
  const $ = _cheerio.default.load(getSDKLoader());
  const script = $("script").html();
  let scriptTag;
  const window = {
    name: "xcomponent__ppcheckout__4_0_435__abc12345"
  };
  const document = {
    write: html => {
      scriptTag = html;
    }
  };
  eval(script);
  const $$ = _cheerio.default.load(scriptTag);
  const src = $$("script").attr("src");
  if (src !== sdkUrl) {
    throw new Error(`Expected script url to be ${sdkUrl} - got ${src}`);
  }
});
(0, _vitest.test)("should construct a valid loader even when no url passed with version 4", () => {
  const sdkUrl = "https://www.paypalobjects.com/api/checkout.js";
  const {
    getSDKLoader
  } = (0, _.unpackSDKMeta)();
  const $ = _cheerio.default.load(getSDKLoader());
  const script = $("script").html();
  let scriptTag;
  const window = {
    name: "xcomponent__ppcheckout__4__abc12345"
  };
  const document = {
    write: html => {
      scriptTag = html;
    }
  };
  eval(script);
  const $$ = _cheerio.default.load(scriptTag);
  const scriptz = $$("script[data-paypal-checkout]");
  const src = scriptz.attr("src");
  if (src !== sdkUrl) {
    throw new Error(`Expected script url to be ${sdkUrl} - got ${src}`);
  }
});
(0, _vitest.test)("should construct a valid loader even when no url passed with version 5 in a popup", () => {
  const sdkUrl = "https://www.paypal.com/sdk/js?client-id=foobarbaz";
  const {
    getSDKLoader
  } = (0, _.unpackSDKMeta)();
  const $ = _cheerio.default.load(getSDKLoader());
  const script = $("script").html();
  let scriptTag;
  const window = {
    opener: {
      document: {
        querySelector: selector => {
          if (selector !== 'script[src*="/sdk/js"]') {
            throw new Error(`Expected selector to be 'script[src*="/sdk/js"]', got ${selector}`);
          }
          return {
            src: sdkUrl
          };
        }
      }
    }
  };
  const document = {
    write: html => {
      scriptTag = html;
    }
  };
  eval(script);
  const $$ = _cheerio.default.load(scriptTag);
  const scriptz = $$("script");
  const src = scriptz.attr("src");
  if (src !== sdkUrl) {
    throw new Error(`Expected script url to be ${sdkUrl} - got ${src}`);
  }
});
(0, _vitest.test)("should construct a valid loader even when no url passed with version 5 in an iframe", () => {
  const sdkUrl = "https://www.paypal.com/sdk/js?client-id=foobarbaz";
  const {
    getSDKLoader
  } = (0, _.unpackSDKMeta)();
  const $ = _cheerio.default.load(getSDKLoader());
  const script = $("script").html();
  let scriptTag;
  const window = {
    parent: {
      document: {
        querySelector: selector => {
          if (selector !== 'script[src*="/sdk/js"]') {
            throw new Error(`Expected selector to be 'script[src*="/sdk/js"]', got ${selector}`);
          }
          return {
            src: sdkUrl
          };
        }
      }
    }
  };
  const document = {
    write: html => {
      scriptTag = html;
    }
  };
  eval(script);
  const $$ = _cheerio.default.load(scriptTag);
  const scriptz = $$("script");
  const src = scriptz.attr("src");
  if (src !== sdkUrl) {
    throw new Error(`Expected script url to be ${sdkUrl} - got ${src}`);
  }
});
(0, _vitest.test)("should error out if a non http or https url passed", () => {
  const sdkUrl = "data://www.paypalobjects.com/api/checkout.js";
  let error;
  try {
    (0, _.unpackSDKMeta)(Buffer.from(JSON.stringify({
      url: sdkUrl
    })).toString("base64"));
  } catch (err) {
    error = err;
  }
  if (!error) {
    throw new Error(`Expected error to be thrown`);
  }
});
(0, _vitest.test)("should error out if a non http or https url passed for the sdk", () => {
  const sdkUrl = "data://www.paypal.com/sdk/js?client-id=foo";
  let error;
  try {
    (0, _.unpackSDKMeta)(Buffer.from(JSON.stringify({
      url: sdkUrl
    })).toString("base64"));
  } catch (err) {
    error = err;
  }
  if (!error) {
    throw new Error(`Expected error to be thrown`);
  }
});
(0, _vitest.test)("should error out if special characters are passed in the checkout.js path", () => {
  const sdkUrl = "https://www.paypalobjects.com/**/checkout.js";
  let error;
  try {
    (0, _.unpackSDKMeta)(Buffer.from(JSON.stringify({
      url: sdkUrl
    })).toString("base64"));
  } catch (err) {
    error = err;
  }
  if (!error) {
    throw new Error(`Expected error to be thrown`);
  }
});
(0, _vitest.test)("should error out if a double && passed in the sdk url", () => {
  const sdkUrl = "https://www.paypal.com/sdk/js?client-id=foo&&currency=USD";
  let error;
  try {
    (0, _.unpackSDKMeta)(Buffer.from(JSON.stringify({
      url: sdkUrl
    })).toString("base64"));
  } catch (err) {
    error = err;
  }
  if (!error) {
    throw new Error(`Expected error to be thrown`);
  }
});
(0, _vitest.test)("should error out if sdk url ends with &", () => {
  const sdkUrl = "https://www.paypal.com/sdk/js?client-id=foo&";
  let error;
  try {
    (0, _.unpackSDKMeta)(Buffer.from(JSON.stringify({
      url: sdkUrl
    })).toString("base64"));
  } catch (err) {
    error = err;
  }
  if (!error) {
    throw new Error(`Expected error to be thrown`);
  }
});
(0, _vitest.test)("should construct a valid script url with paypalobjects on http", () => {
  const sdkUrl = "http://www.paypalobjects.com/api/checkout.js";
  const {
    getSDKLoader
  } = (0, _.unpackSDKMeta)(Buffer.from(JSON.stringify({
    url: sdkUrl
  })).toString("base64"));
  const $ = _cheerio.default.load(getSDKLoader());
  const script = $("script[data-paypal-checkout]");
  const src = script.attr("src");
  if (src !== sdkUrl) {
    throw new Error(`Expected script url to be ${sdkUrl} - got ${src}`);
  }
});
(0, _vitest.test)("should construct a valid min script url with paypalobjects on http", () => {
  const sdkUrl = "http://www.paypalobjects.com/api/checkout.min.js";
  const {
    getSDKLoader
  } = (0, _.unpackSDKMeta)(Buffer.from(JSON.stringify({
    url: sdkUrl
  })).toString("base64"));
  const $ = _cheerio.default.load(getSDKLoader());
  const script = $("script[data-paypal-checkout]");
  const src = script.attr("src");
  if (src !== sdkUrl) {
    throw new Error(`Expected script url to be ${sdkUrl} - got ${src}`);
  }
});
(0, _vitest.test)("should construct a valid script url hosted on objects.paypal.cn", () => {
  const sdkUrl = "http://www.objects.paypal.cn/api/checkout.js";
  const {
    getSDKLoader
  } = (0, _.unpackSDKMeta)(Buffer.from(JSON.stringify({
    url: sdkUrl
  })).toString("base64"));
  const $ = _cheerio.default.load(getSDKLoader());
  const script = $("script[data-paypal-checkout]");
  const src = script.attr("src");
  if (src !== sdkUrl) {
    throw new Error(`Expected script url to be ${sdkUrl} - got ${src}`);
  }
});
(0, _vitest.test)("should construct a valid script url hosted on www.paypal.cn", () => {
  const sdkUrl = "https://www.paypal.cn/sdk/js?client-id=foo";
  const {
    getSDKLoader
  } = (0, _.unpackSDKMeta)(Buffer.from(JSON.stringify({
    url: sdkUrl
  })).toString("base64"));
  const $ = _cheerio.default.load(getSDKLoader());
  const src = $("script").attr("src");
  if (src !== sdkUrl) {
    throw new Error(`Expected script url to be ${sdkUrl} - got ${src}`);
  }
});
(0, _vitest.test)('should error when the script url does not start with "https://" or "http://"', () => {
  const sdkUrl = "\uFEFFhttps://www.paypal.com/sdk/js?client-id=foo";
  const sdkUrlLegacy = "\uFEFFhttp://www.paypalobjects.com/api/checkout.js";
  let error;
  try {
    (0, _.unpackSDKMeta)(Buffer.from(JSON.stringify({
      url: sdkUrl
    })).toString("base64"));
  } catch (err) {
    error = err;
  }
  if (!error) {
    throw new Error(`Expected error to be thrown`);
  }
  try {
    (0, _.unpackSDKMeta)(Buffer.from(JSON.stringify({
      url: sdkUrlLegacy
    })).toString("base64"));
  } catch (err) {
    error = err;
  }
  if (!error) {
    throw new Error(`Expected error to be thrown`);
  }
});
(0, _vitest.test)("should error when invalid characters are found in the subdomain - we allow letters, numbers, . and -", () => {
  const sdkUrl = "https://\uff3cU0022\uff3cU003E\uff3cU003C\uff3cU002Fscript\uff3cU003E\uff3cU003Ciframe\uff3cU0020srcdoc\uff3cU003D\uff3cU0027.www.paypal.com/sdk/js?client-id=foo";
  let error;
  try {
    (0, _.unpackSDKMeta)(Buffer.from(JSON.stringify({
      url: sdkUrl
    })).toString("base64"));
  } catch (err) {
    error = err;
  }
  if (!error) {
    throw new Error(`Expected error to be thrown`);
  }
});
(0, _vitest.test)("should construct a valid web-sdk bridge url", () => {
  const sdkUrl = "https://www.paypal.com/web-sdk/v6/bridge?version=1.2.3&origin=https%3A%2F%2Fwww.example.com%3A8000&payment-flow=payment-handler&debug=true";
  const sdkUID = "abc123";
  const {
    getSDKLoader
  } = (0, _.unpackSDKMeta)(Buffer.from(JSON.stringify({
    url: sdkUrl,
    attrs: {
      "data-uid": sdkUID
    }
  })).toString("base64"));
  const $ = _cheerio.default.load(getSDKLoader());
  const script = $("script");
  const src = script.attr("src");
  const uid = script.attr("data-uid");
  if (src !== sdkUrl) {
    throw new Error(`Expected script url to be ${sdkUrl} - got ${src}`);
  }
  if (uid !== sdkUID) {
    throw new Error(`Expected data UID be ${sdkUID} - got ${uid}`);
  }
});
const validWebSDKBridgeUrls = ["https://www.paypal.com/web-sdk/v6/bridge", "https://www.paypal.com/web-sdk/v6/bridge/popup-bridge", "https://www.paypal.com/web-sdk/v6/bridge/popup/handler", "https://www.paypal.com/web-sdk/v6/bridge?version=1.2.3&origin=https%3A%2F%2Fwww.example.com%3A8000&payment-flow=payment-handler&debug=true&foo=bar", "https://www.paypal.com/web-sdk/v6/bridge?version=1.2.3&origin=https%3A%2F%2Fwww.example.com%3A8000&presentation-mode=payment-handler&foo=bar", "https://www.paypal.com/web-sdk/v6.48.1/bridge", "https://www.paypal.com/web-sdk/v6.48.1/bridge?origin=https%3A%2F%2Fwww.example.com%3A8000&payment-flow=payment-handler&foo=bar", "https://www.paypal.com/web-sdk/v6.48.1/bridge?origin=https%3A%2F%2Fwww.example.com%3A8000&presentation-mode=payment-handler&foo=bar", "https://www.paypal.com/web-sdk/v6.48.1/bridge/popup-bridge", "https://www.paypal.com/web-sdk/v6.48.1-beta.1/bridge"];
_vitest.test.each(validWebSDKBridgeUrls)("should construct a valid web-sdk bridge script tag for %s", sdkUrl => {
  const {
    getSDKLoader
  } = (0, _.unpackSDKMeta)(Buffer.from(JSON.stringify({
    url: sdkUrl,
    attrs: {}
  })).toString("base64"));
  const $ = _cheerio.default.load(getSDKLoader());
  const script = $("script");
  const src = script.attr("src");
  if (src !== sdkUrl) {
    throw new Error(`Expected script url to be ${sdkUrl} - got ${src}`);
  }
});
const invalidWebSDKBridgeUrls = ["https://www.paypal.com/web-sdk/v/bridge", "https://www.paypal.com/web-sdk/v^1.2.3/bridge", "https://www.paypal.com/web-sdk/v6/not-bridge", "https://www.paypal.com/web-sdk/v6/bridge/../../../any-path-on-paypal", "https://www.paypal.com/web-sdk/v6/bridge%2F..%2F..%2Fany-path-on-paypal", "https://www.paypal.com/web-sdk/v6%00/bridge", "https://www.paypal.com/web-sdk/v6/BRIDGE", "https://www.paypal.com/web-sdk/6/bridge", "https://www.paypal.com/web-sdk/v6", "https://www.paypal.com/web-sdk/js", "https://www.paypal.com/web-sdk/v6/js"];
_vitest.test.each(invalidWebSDKBridgeUrls)("should error for invalid web-sdk bridge url: %s", sdkUrl => {
  let error = null;
  try {
    (0, _.unpackSDKMeta)(Buffer.from(JSON.stringify({
      url: sdkUrl,
      attrs: {}
    })).toString("base64"));
  } catch (err) {
    error = err;
  }
  if (!error) {
    throw new Error("Expected error to be thrown");
  }
  if (!error.message.includes("web-sdk bridge url")) {
    throw new Error(`Expected error message to mention "web-sdk bridge url", got: ${error.message}`);
  }
});
(0, _vitest.test)("should encode unsafe characters in web-sdk bridge url", () => {
  const sdkUrl = "https://www.paypal.com/web-sdk/v6/bridge?foo=bar\" onload=\"alert('xss')";
  const {
    getSDKLoader
  } = (0, _.unpackSDKMeta)(Buffer.from(JSON.stringify({
    url: sdkUrl,
    attrs: {}
  })).toString("base64"));
  const $ = _cheerio.default.load(getSDKLoader());
  if ($("script").attr("onload") !== undefined) {
    throw new Error("Expected onload attribute to not be present");
  }
});
(0, _vitest.test)("should encode script tag injection in web-sdk bridge url", () => {
  const sdkUrl = "https://www.paypal.com/web-sdk/v6/bridge?foo=bar\"></script><script>alert('xss')</script><script src=\"";
  const {
    getSDKLoader
  } = (0, _.unpackSDKMeta)(Buffer.from(JSON.stringify({
    url: sdkUrl,
    attrs: {}
  })).toString("base64"));
  const $ = _cheerio.default.load(getSDKLoader());
  if ($("script").length !== 1) {
    throw new Error(`Expected exactly 1 script element, got ${$("script").length}`);
  }
});
(0, _vitest.test)("should construct a valid web-sdk bridge url without invalid attributes", () => {
  const sdkUrl = "https://www.paypal.com/web-sdk/v6/bridge";
  const {
    getSDKLoader
  } = (0, _.unpackSDKMeta)(Buffer.from(JSON.stringify({
    url: sdkUrl,
    attrs: {
      "data-uid": "abc123",
      onload: "alert('xss')"
    }
  })).toString("base64"));
  const $ = _cheerio.default.load(getSDKLoader());
  const src = $("script").attr("src");
  const uid = $("script").attr("data-uid");
  const onload = $("script").attr("onload");
  if (src !== sdkUrl) {
    throw new Error(`Expected script url to be ${sdkUrl} - got ${src}`);
  }
  if (uid !== "abc123") {
    throw new Error(`Expected data-uid to be "abc123" - got ${uid}`);
  }
  if (onload !== undefined) {
    throw new Error(`Expected invalid attribute to be undefined - got ${onload}`);
  }
});
(0, _vitest.test)("should encode unsafe characters in web-sdk bridge data attribute values", () => {
  const sdkUrl = "https://www.paypal.com/web-sdk/v6/bridge";
  const {
    getSDKLoader
  } = (0, _.unpackSDKMeta)(Buffer.from(JSON.stringify({
    url: sdkUrl,
    attrs: {
      "data-uid": "\" onload=\"alert('xss')"
    }
  })).toString("base64"));
  const $ = _cheerio.default.load(getSDKLoader());
  if ($("script").attr("onload") !== undefined) {
    throw new Error("Expected onload attribute to not be present");
  }
});
(0, _vitest.test)("should encode script tag injection in web-sdk bridge data attribute values", () => {
  const sdkUrl = "https://www.paypal.com/web-sdk/v6/bridge";
  const {
    getSDKLoader
  } = (0, _.unpackSDKMeta)(Buffer.from(JSON.stringify({
    url: sdkUrl,
    attrs: {
      "data-uid": "\"></script><script>alert('xss')</script><script src=\""
    }
  })).toString("base64"));
  const $ = _cheerio.default.load(getSDKLoader());
  if ($("script").length !== 1) {
    throw new Error(`Expected exactly 1 script element, got ${$("script").length}`);
  }
});
(0, _vitest.test)("should not allow attribute injection via spaces in web-sdk bridge data attribute name", () => {
  const sdkUrl = "https://www.paypal.com/web-sdk/v6/bridge";
  const {
    getSDKLoader
  } = (0, _.unpackSDKMeta)(Buffer.from(JSON.stringify({
    url: sdkUrl,
    attrs: {
      "data-x onload": "alert('xss')"
    }
  })).toString("base64"));
  const $ = _cheerio.default.load(getSDKLoader());
  if ($("script").attr("onload") !== undefined) {
    throw new Error("Expected onload attribute to not be present");
  }
});
(0, _vitest.test)("should include sdk-client version as a data attribute for web-sdk bridge urls", () => {
  const sdkUrl = "https://www.paypal.com/web-sdk/v6/bridge";
  const semverRegex = /^[0-9.A-Za-z-+]+$/;
  const {
    getSDKLoader
  } = (0, _.unpackSDKMeta)(Buffer.from(JSON.stringify({
    url: sdkUrl,
    attrs: {}
  })).toString("base64"));
  const $ = _cheerio.default.load(getSDKLoader());
  const version = $("script").attr("data-sdk-meta-contract-version");
  if (!semverRegex.test(version)) {
    throw new Error(`Expected data-sdk-meta-contract-version to be a valid version - got "${version}"`);
  }
  if (version !== _constants.VERSION) {
    throw new Error(`Expected data-sdk-meta-contract-version to be "${_constants.VERSION}" - got "${version}"`);
  }
});