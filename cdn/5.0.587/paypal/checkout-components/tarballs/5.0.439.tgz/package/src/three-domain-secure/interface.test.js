/* @flow */
import {
  getEnv,
  getLogger,
  getPayPalAPIDomain,
  getSDKToken,
  getUserIDToken,
  getClientID,
} from "@paypal/sdk-client/src";
import { beforeEach, describe, expect, vi } from "vitest";
import { destroy as zoidDestroy } from "@krakenjs/zoid/src";

import { ThreeDomainSecureComponent } from "./component";
import { GraphQLClient, RestClient } from "./api";
import { getThreeDS } from "./utils";
import { setup, destroy, ThreeDomainSecureClient } from "./interface";

const { stableLoggerMock } = vi.hoisted(() => ({
  stableLoggerMock: {
    addMetaBuilder: vi.fn(),
    immediateFlush: vi.fn().mockResolvedValue(undefined),
  },
}));

vi.mock("@paypal/sdk-client/src", () => ({
  getEnv: vi.fn(),
  getPayPalAPIDomain: vi.fn(),
  getSDKToken: vi.fn(),
  getUserIDToken: vi.fn(),
  getClientID: vi.fn(),
  // src/lib/fpti-ip-masking.js registers a meta builder on module load;
  // a fully auto-mocked getLogger() returns undefined, which would throw
  // when that registration runs. The real getLogger() is a memoized
  // singleton, so this mock returns the same stable object on every call
  // too - a test asserts on the exact object passed via getLogger().
  getLogger: vi.fn(() => stableLoggerMock),
}));
vi.mock("@krakenjs/zoid/src");
vi.mock("./component");
vi.mock("./api");
vi.mock("./utils");

describe("ThreeDomainSecure interface", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("should setup and destroy", () => {
    setup();
    expect(getThreeDS).toHaveBeenCalledTimes(1);

    const err = new Error("test error");
    destroy(err);
    expect(zoidDestroy).toHaveBeenCalledTimes(1);
    expect(zoidDestroy).toHaveBeenCalledWith(err);
  });

  it("should create and return instance of ThreeDomainSecureClient only on dev environment", async () => {
    vi.mocked(getEnv).mockReturnValue("stage");
    vi.mocked(getSDKToken).mockReturnValue("test-token");
    vi.mocked(getUserIDToken).mockReturnValue(undefined);
    vi.mocked(getPayPalAPIDomain).mockReturnValue("test-domain");
    vi.mocked(getClientID).mockReturnValue("test-client-id");

    const threeDomainSecureInstance = ThreeDomainSecureClient.__get__();
    expect(threeDomainSecureInstance).toBeDefined();
    // $FlowIssue
    expect(threeDomainSecureInstance.isEligible).toBeDefined();
    // $FlowIssue
    expect(threeDomainSecureInstance.show).toBeDefined();

    // Replicating testbed changes
    const threeDSComponentInstance = new ThreeDomainSecureComponent({
      logger: getLogger(),
      restClient: new RestClient(),
      graphQLClient: new GraphQLClient({
        baseURL: "https://payments.sandbox.braintree-api.com",
        accessToken: "test-token",
      }),
      sdkConfig: {
        authenticationToken: "test-token",
        paypalApiDomain: "test-domain",
        clientID: "test-client-id",
      },
    });

    const payload = {
      amount: "10.00",
      currency: "USD",
      nonce: "fastlane-nonce",
    };

    await threeDSComponentInstance.isEligible(payload);
    // $FlowIssue
    expect(threeDSComponentInstance.isEligible).toHaveBeenCalledWith(payload);

    await threeDSComponentInstance.show();
    // $FlowIssue
    expect(threeDSComponentInstance.show).toHaveBeenCalledTimes(1);

    // instance check
    expect(ThreeDomainSecureComponent).toHaveBeenCalledWith({
      logger: getLogger(),
      restClient: expect.any(RestClient),
      graphQLClient: expect.any(GraphQLClient),
      sdkConfig: {
        authenticationToken: "test-token",
        paypalApiDomain: "test-domain",
        clientID: "test-client-id",
      },
    });
  });

  it("should not throw during __get__ when sdk token is missing", () => {
    vi.mocked(getEnv).mockReturnValue("stage");
    vi.mocked(getSDKToken).mockReturnValue(undefined);
    vi.mocked(getUserIDToken).mockReturnValue(undefined);
    vi.mocked(getPayPalAPIDomain).mockReturnValue("test-domain");
    vi.mocked(getClientID).mockReturnValue("test-client-id");

    expect(() => ThreeDomainSecureClient.__get__()).not.toThrow();
    expect(ThreeDomainSecureComponent).not.toHaveBeenCalled();
  });
});
