/* @flow */

export type ModalProps = {||};
