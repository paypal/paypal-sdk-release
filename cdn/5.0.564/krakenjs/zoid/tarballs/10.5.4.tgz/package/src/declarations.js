/* @flow */

declare var __ZOID__: {|
  __VERSION__: string,
  __LEGACY_GLOBAL_KEY__: string,
  __MAJOR_VERSION_GLOBAL_KEY__: string,
  __POPUP_SUPPORT__: boolean,
  __IFRAME_SUPPORT__: boolean,
  __FRAMEWORK_SUPPORT__: boolean,
  __DEFAULT_CONTAINER__: boolean,
  __DEFAULT_PRERENDER__: boolean,
  __SCRIPT_NAMESPACE__: boolean,
|};

declare var __DEBUG__: boolean;
